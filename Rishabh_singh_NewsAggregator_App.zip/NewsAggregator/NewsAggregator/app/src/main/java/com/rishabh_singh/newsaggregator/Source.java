package com.rishabh_singh.newsaggregator;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

public class Source implements Serializable, Parcelable{
    private String id;
    private String name;
    private String category;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Source(String sourceId, String sourceName, String sourceCategory) {
        this.id = sourceId;
        this.name = sourceName;
        this.category = sourceCategory;
    }

    protected Source(Parcel in) {
        readFromParcel(in);
    }

    private void readFromParcel(Parcel in) {
        id = in.readString();
        name = in.readString();
        category = in.readString();
    }


    public static final Parcelable.Creator<Source> CREATOR = new Parcelable.Creator<Source>() {
        @Override
        public Source createFromParcel(Parcel in) {
            return new Source(in);
        }

        @Override
        public Source[] newArray(int size) {
            return new Source[size];
        }
    };


    @Override
    public int describeContents() {
        return 0;
    }


    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(id);
        parcel.writeString(name);
        parcel.writeString(category);
    }

}
