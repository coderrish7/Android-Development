package com.rishabh_singh.newsaggregator;

import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.RequiresApi;

import java.io.Serializable;
import java.time.LocalDateTime;

public class Article implements Parcelable, Serializable {
    private String newsauthor;
    private String newstitle;
    private String newsdescription;
    private String sourceurl;
    private String urlToImage;
    private LocalDateTime publishedAt;

    protected Article(Parcel in) {
        newsauthor = in.readString();
        newstitle = in.readString();
        newsdescription = in.readString();
        sourceurl = in.readString();
        urlToImage = in.readString();
    }
    public Article(String articleAuthor, String articleTitle, String articleDescription,
                   String articleUrl, String articleImageUrl, LocalDateTime articlePublishedTime) {
        super();
        newsauthor = articleAuthor;
        newstitle = articleTitle;
        newsdescription = articleDescription;
        sourceurl = articleUrl;
        urlToImage = articleImageUrl;
        publishedAt = articlePublishedTime;
    }

    public String getNewsauthor() {
        return newsauthor;
    }

    public String getNewstitle() {
        return newstitle;
    }

    public String getNewsdescription() {
        return newsdescription;
    }

    public String getSourceurl() {
        return sourceurl;
    }

    public String getUrlToImage() {
        return urlToImage;
    }

    public LocalDateTime getPublishedAt() {
        return publishedAt;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(newsauthor);
        parcel.writeString(newstitle);
        parcel.writeString(newsdescription);
        parcel.writeString(sourceurl);
        parcel.writeString(urlToImage);
        parcel.writeString(NewsDownloader.dtformat(publishedAt));
    }

    public static final Parcelable.Creator<Article> CREATOR = new Parcelable.Creator<Article>() {
        @Override
        public Article createFromParcel(Parcel in) {
            return new Article(in);
        }

        @Override
        public Article[] newArray(int size) {
            return new Article[size];
        }
    };
}
