package com.rishabh_singh.newsaggregator;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class SourceDownloader {
    private static MainActivity activity;
    private static RequestQueue queue;
    private static final String API_KEY = "d765afa6ffd94711ab0c5b388464cd2d";

    public static void sourcedownloader(MainActivity mainActivityIn) {
        activity = mainActivityIn;
        String sourceApiUrl = "https://newsapi.org/v2/sources?apiKey=" + API_KEY;
        queue = Volley.newRequestQueue(activity);

        JsonObjectRequest jsonObjectRequest = createJsonObjectRequest(sourceApiUrl);
        queue.add(jsonObjectRequest);
    }

    private static JsonObjectRequest createJsonObjectRequest(String sourceApiUrl) {
        Response.Listener<JSONObject> listener = response -> {
            parseJSON(response.toString());
        };

        Response.ErrorListener error = error1 -> activity.displayToastSourcesFailed();

        return new JsonObjectRequest(Request.Method.GET, sourceApiUrl, null, listener, error) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                headers.put("User-Agent", "News-App");
                return headers;
            }
        };
    }


    static void parseJSON(String s) {

        try {
            JSONObject jsonObjectMain = new JSONObject(s);
            JSONArray sourceList = jsonObjectMain.getJSONArray("sources");
            ArrayList<Source> sourcesList = new ArrayList<>();
            Set<String> categories = new HashSet<>();

            for (int i = 0; i < sourceList.length(); i++)
            {
                JSONObject sourceObj = sourceList.getJSONObject(i);
                String category = sourceObj.getString("category");
                Source source = new Source(sourceObj.getString("id"), sourceObj.getString("name"), category);
                categories.add(category);
                sourcesList.add(source);
            }
            activity.updateData(sourcesList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
