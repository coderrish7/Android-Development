package com.rishabh_singh.newsaggregator;

import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ArticleViewHolder extends RecyclerView.ViewHolder {
    ImageView image;
    TextView strBody;
    TextView articleCount;
    TextView strHeading;
    TextView date;
    TextView strauthor;



    public ArticleViewHolder(@NonNull View itemView) {
        super(itemView);
        strHeading = itemView.findViewById(R.id.headingArticle);
        date = itemView.findViewById(R.id.calenderArticle);
        strauthor = itemView.findViewById(R.id.publisherArticle);
        image = itemView.findViewById(R.id.contentArticle);
        strBody = itemView.findViewById(R.id.descriptionArticle);
        articleCount = itemView.findViewById(R.id.numbercountArticle);
        strBody.setMovementMethod(new ScrollingMovementMethod());
    }
}
