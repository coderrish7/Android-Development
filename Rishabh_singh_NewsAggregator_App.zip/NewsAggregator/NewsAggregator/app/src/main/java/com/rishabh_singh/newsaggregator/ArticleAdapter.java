package com.rishabh_singh.newsaggregator;

import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Locale;

public class ArticleAdapter extends RecyclerView.Adapter<ArticleViewHolder>{
    private final MainActivity activity;
    private final ArrayList<Article> articles;
    public String launchURL;

    public ArticleAdapter(MainActivity mainActivity, ArrayList<Article> articles) {
        this.activity = mainActivity;
        this.articles = articles;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onBindViewHolder(@NonNull ArticleViewHolder holder, int position) {
        Article article = articles.get(position);

        holder.articleCount.setText(String.format(Locale.getDefault(), "%d of %d", position + 1, articles.size()));

        setTextField(holder.strHeading, article.getNewstitle());
        setTextField(holder.strauthor, article.getNewsauthor());
        setTextField(holder.strBody, article.getNewsdescription());

        if (article.getUrlToImage() != null) {
            Picasso.get().load(article.getUrlToImage())
                    .placeholder(R.drawable.loading)
                    .error(R.drawable.brokenimage)
                    .into(holder.image);
        } else {
            holder.image.setImageResource(R.drawable.noimage);
        }

        if (article.getPublishedAt() != null) {
            holder.date.setText(NewsDownloader.dtformat(article.getPublishedAt()));
            holder.date.setVisibility(View.VISIBLE);
        } else {
            holder.date.setVisibility(View.GONE);
        }

        launchURL = article.getSourceurl();
    }
    @Override
    public int getItemCount() {
        return articles.size();
    }
    private void setTextField(TextView textView, String content) {
        if (content != null) {
            textView.setText(content);
            textView.setVisibility(View.VISIBLE);
        } else {
            textView.setVisibility(View.GONE);
        }
    }
    @NonNull
    @Override
    public ArticleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = inflateLayout(parent);
        return new ArticleViewHolder(itemView);
    }

    private View inflateLayout(ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        return inflater.inflate(R.layout.activity_layout, parent, false);
    }

}
