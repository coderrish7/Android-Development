package com.rishabh_singh.newsaggregator;

import android.os.Build;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.util.Locale;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class NewsDownloader {
    private static final String TAG = "NewsDownloader";
    private static String sourceID;
    private static MainActivity activity;
    private static RequestQueue queue;

    private static final String apiKey = "d765afa6ffd94711ab0c5b388464cd2d";

    private static String createArticleApiUrl(String sourceId) {
        return "https://newsapi.org/v2/top-headlines?sources=" + sourceId + "&apiKey=" + NewsDownloader.apiKey;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static void downloadNewsArticle(MainActivity mainActivity, String sourceId) {
        activity = mainActivity;
        sourceID = sourceId;
        queue = Volley.newRequestQueue(activity);

        String articleApiUrl = createArticleApiUrl(sourceID);

        Response.Listener<JSONObject> listener = response -> {
            parseJSON(response.toString());
        };

        Response.ErrorListener articleError = error -> Toast.makeText(activity, "NO API Response", Toast.LENGTH_SHORT).show();

        JsonObjectRequest articleJsonObjectRequest = new JsonObjectRequest(Request.Method.GET, articleApiUrl, null, listener, articleError) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                headers.put("User-Agent", "News-App");
                return headers;
            }
        };

        queue.add(articleJsonObjectRequest);
    }


    private static String getStringField(JSONObject obj, String field) {
        try {
            if (obj.has(field) && !obj.isNull(field)) {
                return obj.getString(field);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    private static void parseJSON(String s) {
        try {
            JSONObject jObjMain = new JSONObject(s);

            JSONArray articleList = jObjMain.getJSONArray("articles");
            ArrayList<Article> articles = new ArrayList<>();

            for (int i = 0; i < articleList.length(); i++) {
                JSONObject article = articleList.getJSONObject(i);

                String publishedAtStr = article.optString("publishedAt", null);

                Article newArticle = null;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    newArticle = new Article(
                            getStringField(article, "strauthor"),
                            getStringField(article, "title"),
                            getStringField(article, "strBody"),
                            getStringField(article, "url"),
                            getStringField(article, "urlToImage"),
                            parseDate(publishedAtStr)
                    );
                }
                articles.add(newArticle);
            }

            activity.fetchArticles(articles);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static String dtformat(LocalDateTime ldt) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMM dd, yyyy h:mm", Locale.getDefault());
        return ldt.format(dtf);
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    public static LocalDateTime parseDate(String date) {
        if (date == null || date.equals("null")) {
            return null;
        }
        DateTimeFormatter formatter = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            formatter = new DateTimeFormatterBuilder()
                    .append(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
                    .optionalStart()
                    .appendOffset("+HH:MM", "+00:00")
                    .optionalEnd()
                    .optionalStart()
                    .appendOffset("+HHMM", "+0000")
                    .optionalEnd()
                    .optionalStart()
                    .appendOffset("+HH", "Z")
                    .optionalEnd()
                    .toFormatter();
        }

        try {
            return LocalDateTime.parse(date, formatter);
        } catch (DateTimeParseException e) {
            e.printStackTrace();
            return null;
        }
    }
}
