package com.rishabh_singh.newsaggregator;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager2.widget.ViewPager2;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public class MainActivity extends AppCompatActivity {
    private Menu menu;
    private DrawerLayout drawerLayout;
    private ListView listView;
    private ActionBarDrawerToggle actionBarDrawerToggle;
    private ArticleAdapter adapter;
    private ViewPager2 pager2;

    private String categoryselected;
    private Source sourceSelected;

    
    private ArrayList<Article> articleArrayList = new ArrayList<>();
    private List<Source> selectedSourcesList = new ArrayList<>();

    private ArrayList<Source> sources = new ArrayList<>();
    private ArrayList<String> categories = new ArrayList<>(
    );
    private ArrayList<String> colors = new ArrayList<>();


    private final HashMap<String, ArrayList<Source>> contentData = new HashMap<>();
    private final ArrayList<Source> contentList = new ArrayList<>();

    public HashMap<String, Integer> colorChart = new HashMap<>();
    private final ArrayList<Integer> colorArray = new ArrayList<>();

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.optionDrawer);
        listView.setOnItemClickListener((parent, view, position, id) -> categorywiseTopic(position));

        drawerLayout = findViewById(R.id.drawerLayout);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.drawer_open, R.string.drawer_close);
        pager2 = findViewById(R.id.page);
        adapter = new ArticleAdapter(this, articleArrayList);
        pager2.setAdapter(adapter);

        loadData();

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            ((ActionBar) actionBar).setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeButtonEnabled(true);
        }

        setcolourmenu(getApplicationContext());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        setMenu(menu);
        return super.onCreateOptionsMenu(menu);
    }

    private void setMenu(Menu menu) {
        this.menu = menu;
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        syncActionBarDrawerToggle();
    }

    private void syncActionBarDrawerToggle() {
        if (actionBarDrawerToggle != null) {
            actionBarDrawerToggle.syncState();
        }
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        if (actionBarDrawerToggle != null) {
            actionBarDrawerToggle.onConfigurationChanged(newConfig);
        }
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }

        String title = item.getTitle().toString();
        ArrayList<Source> clist = contentData.get(title);
        sources.clear();
        contentData.put("All", contentList);

        if (clist != null) {
            sources.addAll(clist);
            setTitle(new StringBuilder().append(title).append(" (").append(clist.size()).append(")").toString());
        } else {
            setTitle(title);
        }

        filterSourceList();
        return super.onOptionsItemSelected(item);
    }

    private void filterSourceList() {
        selectedSourcesList = sources.stream()
                .filter(s -> categoryselected == null || s.getCategory().equals(categoryselected))
                .collect(Collectors.toList());

        if (selectedSourcesList.isEmpty()) {
            NoSourcesDialogbox();
        }

        SourceAdapter adapter = new SourceAdapter(this, R.layout.listitem_drawer, selectedSourcesList.toArray(new Source[0]));
        listView.setAdapter(adapter);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeButtonEnabled(true);
        }
    }
    public void onClickOpenURL(View view) {
        String urlToLaunch = adapter.launchURL;
        if (urlToLaunch == null) {
            return;
        }

        Uri uri = Uri.parse(urlToLaunch.replace("http:", "https:"));
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }


    private void setcolourmenu(Context context) {
        int[] colorIds = {R.color.menuCategory1, R.color.menuCategory2, R.color.menuCategory3,
                R.color.menuCategory4, R.color.menuCategory5, R.color.menuCategory6,
                R.color.menuCategory7, R.color.menuCategory8, R.color.menuCategory9,
                R.color.menuCategory10};
        for (int id : colorIds) {
            colorArray.add(ContextCompat.getColor(context, id));
        }
    }

        private void NoSourcesDialogbox() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("No sources are available");
        builder.setMessage(
                "No sources exist matching the specified category");
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    @SuppressLint("DefaultLocale")
    public void updateData(ArrayList<Source> sourceList) {
        this.sources = sourceList;

        for (Source s : sourceList) {
            contentData.computeIfAbsent(s.getCategory(), k -> new ArrayList<>()).add(s);
        }

        contentData.put("All", sourceList);
        ArrayList<String> categories = new ArrayList<>(contentData.keySet());
        Collections.sort(categories);

        for (int i = 0; i < categories.size(); i++) {
            String category = categories.get(i);
            int color = colorArray.get(i % colorArray.size());
            colorChart.put(category, color);

            MenuItem item = menu.add(category);
            SpannableString title = new SpannableString(category);
            title.setSpan(new ForegroundColorSpan(color), 0, title.length(), 0);
            item.setTitle(title);
        }

        this.contentList.addAll(sourceList);
        int numSources = this.contentList.size();
        setTitle("News Gateway" + (numSources > 0 ? String.format(" (%d)", numSources) : ""));

        SourceAdapter adapter = new SourceAdapter(this, R.layout.listitem_drawer, this.contentList.toArray(new Source[0]));
        listView.setAdapter(adapter);

        filterSourceList();
    }

    public void loadData() {
        if (hasNetworkConnection(this)) {
            SourceDownloader.sourcedownloader(this);
        } else {

            showNoConnectionMessage();
        }
    }
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    public void displayToastSourcesFailed() {
        showToast(getString(R.string.error_sources));
    }

    private void showNoConnectionMessage() {
        Toast.makeText(this, R.string.no_connection, Toast.LENGTH_SHORT).show();
    }

    public static boolean hasNetworkConnection(Activity activity) {
        ConnectivityManager connectivityManager =
                activity.getSystemService(ConnectivityManager.class);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return networkInfo != null && networkInfo.isConnectedOrConnecting();
    }

    @SuppressLint("NotifyDataSetChanged")
    public void fetchArticles(ArrayList<Article> articles) {
        this.articleArrayList.clear();
        this.articleArrayList.addAll(articles);
        adapter.notifyDataSetChanged();

        if (this.articleArrayList.isEmpty()) {
            Toast.makeText(this, String.format(Locale.getDefault(), getString(R.string.no_article),
                    sourceSelected.getName()), Toast.LENGTH_SHORT).show();
            return;
        }
        pager2.setBackground(null);
        pager2.setCurrentItem(0);

        setTitle(sourceSelected.getName());
    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    private void categorywiseTopic(int position) {
        sourceSelected = selectedSourcesList.get(position);
        if (this.sourceSelected != null) {
            NewsDownloader.downloadNewsArticle(this, sourceSelected.getId());
            drawerLayout.closeDrawer(listView);
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putString(getString(R.string.selected_category), categoryselected);
        outState.putStringArrayList(getString(R.string.categories), categories);

        if (sources != null) {
            outState.putParcelableArrayList(getString(R.string.sources), new ArrayList<>(sources));
        }

        if (sourceSelected != null) {
            outState.putParcelable(getString(R.string.selected_source), sourceSelected);
        }

        if (articleArrayList != null) {
            outState.putParcelableArrayList(getString(R.string.articles), new ArrayList<>(articleArrayList));
        }

        outState.putInt(getString(R.string.current_article), pager2.getCurrentItem());

        if (colors != null) {
            outState.putStringArrayList(getString(R.string.colors), new ArrayList<>(colors));
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        categoryselected = savedInstanceState.getString(getString(R.string.selected_category));

        categories = savedInstanceState.getStringArrayList(getString(R.string.categories));
        sources = savedInstanceState.getParcelableArrayList(getString(R.string.sources));

        colors = savedInstanceState.getStringArrayList(getString(R.string.colors));

        articleArrayList.addAll(savedInstanceState.getParcelableArrayList(getString(R.string.articles)));

        adapter.notifyDataSetChanged();
        pager2.setBackground(null);
        pager2.setCurrentItem(savedInstanceState.getInt(getString(R.string.current_article)));

        sourceSelected = savedInstanceState.getParcelable(getString(R.string.selected_source));
        filterSourceList();

        if (sourceSelected != null) {
            setTitle(sourceSelected.getName());
        }

        adapter.notifyDataSetChanged();
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to exit?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }


}