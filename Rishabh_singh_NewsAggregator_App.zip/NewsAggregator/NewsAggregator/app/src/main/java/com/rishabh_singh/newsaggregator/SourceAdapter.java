package com.rishabh_singh.newsaggregator;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class SourceAdapter extends ArrayAdapter<Source> {
    private final MainActivity mainActivity;
    private final Source[] sourcedata;

    public SourceAdapter(@NonNull Context context, int resource, @NonNull Source[] objects) {
        super(context, resource, objects);
        this.mainActivity = (MainActivity) context;
        this.sourcedata = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        SourceViewHolder sourceViewHolder;

        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(parent.getContext());
            convertView = inflater.inflate(R.layout.listitem_drawer, parent, false);
            sourceViewHolder = new SourceViewHolder(convertView);
            convertView.setTag(sourceViewHolder);
        } else {
            sourceViewHolder = (SourceViewHolder) convertView.getTag();
        }

        Source source = getItem(position);
        sourceViewHolder.name.setText(source.getName());
        sourceViewHolder.name.setTextColor(mainActivity.colorChart.getOrDefault(source.getCategory(), Color.WHITE));

        return convertView;
    }

}
