package com.example.split;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    private EditText totalBillAmount;
    private EditText totalNumberPeople;
    private TextView totalTip;
    private TextView totalAndTip;
    private TextView totalPP;

    private float totalAnswer;

    public MainActivity() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "onCreate:");
        totalBillAmount = findViewById(R.id.BillTotal);
        totalNumberPeople = findViewById(R.id.TotalPeopleValue);
        totalTip = findViewById(R.id.TipAmountAnswer);
        totalAndTip = findViewById(R.id.TotalTipAnswer);
        totalPP = findViewById(R.id.PerTotalAnswer);
    }

    @SuppressLint("DefaultLocale")
    public void tiperperson(View v){

        String personNumStr = totalNumberPeople.getText().toString();
        if(personNumStr.isEmpty()) {
            Toast.makeText(this,"Please enter Valid Number of People",Toast.LENGTH_SHORT).show();
            return;
        }
        int num;
        num = Integer.parseInt(personNumStr);
        if(num == 0)
        {
            Toast.makeText(this,"Please enter Valid Number of People",Toast.LENGTH_SHORT).show();
            totalNumberPeople.setText("");
        }
        else
        {
            float totalPPAnswer = totalAnswer/num;
            totalPP.setText(String.format("$ %.2f ",totalPPAnswer));
        }

    }

    public void clearAllFields (View v)
    {
        totalBillAmount.setText("");
        totalNumberPeople.setText("");
        totalPP.setText("");
        totalTip.setText("");
        totalAndTip.setText("");

        ((RadioButton) findViewById(R.id.radio12)).setChecked(false);
        ((RadioButton) findViewById(R.id.radio15)).setChecked(false);
        ((RadioButton) findViewById(R.id.radio18)).setChecked(false);
        ((RadioButton) findViewById(R.id.radio20)).setChecked(false);
        totalAnswer = 0;
    }


    @SuppressLint({"NonConstantResourceId", "DefaultLocale"})
    public void calculateTipAmount(View v){

        String totalBillAmountStr = totalBillAmount.getText().toString();

        if(totalBillAmountStr.isEmpty()) {
            RadioButton radiobtn = (RadioButton) findViewById(v.getId());
            radiobtn.setChecked(false);
            return;
        }
        int tipPercent = 0 ;

        switch (v.getId()) {
            case R.id.radio12:
                Toast.makeText(this, "Tip Amount Selected:12", Toast.LENGTH_SHORT).show();
                tipPercent = 12;
                break;
            case R.id.radio15:
                Toast.makeText(this, "Tip Amount Selected:15", Toast.LENGTH_SHORT).show();
                tipPercent = 15;
                break;
            case R.id.radio18:
                Toast.makeText(this, "Tip Amount Selected:18", Toast.LENGTH_SHORT).show();
                tipPercent = 18;
                break;
            case R.id.radio20:
                Toast.makeText(this, "Tip Amount Selected:20", Toast.LENGTH_SHORT).show();
                tipPercent = 20;
                break;
            default:
                Log.d(TAG, "calculateTip: Invalid  ");
                break;
        }

        float total = Float.parseFloat(totalBillAmountStr);
        Log.d(TAG, "calculateTip: " + tipPercent);

        float finalvalue = (total * tipPercent)/100;
        totalAnswer = total + finalvalue;
        totalTip.setText(String.format("$ %.2f ", finalvalue));
        totalAndTip.setText(String.format("$ %.2f ",Float.valueOf(total+finalvalue)));
    }
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {

        outState.putString("TOTALTIP",totalTip.getText().toString());
        outState.putString("TOTALANDTIP",totalAndTip.getText().toString());
        outState.putString("TOTALPERPERSON",totalPP.getText().toString());
        outState.putString("TOTALBILLAMOUNT",totalBillAmount.getText().toString());
        outState.putString("TOTALNUMBEROFPEOPLE",totalNumberPeople.getText().toString());
        outState.putFloat("TOTALANSWER",totalAnswer);
        super.onSaveInstanceState(outState);
        Log.d(TAG, "onSaveInstan ceState: ");
    }
    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Log.d(TAG, "onRestoreInstanceState: ");
        totalTip.setText(savedInstanceState.getString("TOTALTIP"));
        totalAndTip.setText(savedInstanceState.getString("TOTALANDTIP"));
        totalPP.setText(savedInstanceState.getString("TOTALPERPERSON"));
        totalBillAmount.setText(savedInstanceState.getString("TOTALBILLAMOUNT"));
        totalNumberPeople.setText(savedInstanceState.getString("TOTALNUMBEROFPEOPLE"));
        totalAnswer = savedInstanceState.getFloat("TOTALANSWER");
    }
}

