package com.rishabhsingh.androidnotes;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.JsonWriter;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
        implements View.OnClickListener , View.OnLongClickListener{

    private static final String TAG = "MainActivity";

    private RecyclerView recyclerView;

    private LinearLayoutManager linearLayoutManager;
    private ActivityResultLauncher<Intent> activityResultLauncher;
    public final ArrayList<Note> m_notesList = new ArrayList<>();
    private Adapter n_Adapter;
    private int pos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_main);
        String app_name = getResources().getString(R.string.app_name);
        setTitle( app_name + " (" + m_notesList.size() + ")");
        recyclerView = findViewById(R.id.recycler);
        n_Adapter = new Adapter(m_notesList, this);
        linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setAdapter(n_Adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        loadJSONFile();
        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                this::Result);

    }


    @SuppressLint("DefaultLocale")
    public void Result(@NonNull ActivityResult result) {

        if (result.getResultCode() == RESULT_OK) {
            Intent data = result.getData();

            if (data == null) {
                Toast.makeText(this, "Null text value returned", Toast.LENGTH_SHORT).show();
                return;
            }
            if(data.hasExtra("NOTE_OBJECT_NEW"))
            {
                Note oNote = (Note) data.getSerializableExtra("NOTE_OBJECT_NEW");
                m_notesList.add(0, oNote);
                n_Adapter.notifyItemInserted(0);
                linearLayoutManager.scrollToPosition(0);
                String app_name = getResources().getString(R.string.app_name);
                setTitle( app_name + " (" + m_notesList.size() + ")");

            }
            if(data.hasExtra("NOTE_OBJECT_UPDATED"))
            {
                Note oNote = (Note) data.getSerializableExtra("NOTE_OBJECT_UPDATED");
                int posUpdate = data.getIntExtra("UPDATE_POS",-1);
                Log.d(TAG, "onActivityResult:NOTE_OBJECT_UPDATED " );
                Note nUpdate = m_notesList.get(posUpdate);
                m_notesList.remove(posUpdate);
                n_Adapter.notifyItemRemoved(posUpdate);
                m_notesList.add(0,oNote);
                n_Adapter.notifyItemInserted(0);
                setTitle(String.format("Android Notes (%d)",m_notesList.size()));
                linearLayoutManager.scrollToPosition(0);
            }

        } else {
            Log.d(TAG, "onActivityResult: result Code: " + result.getResultCode());
        }
    }
    public boolean onCreateOptionsMenu(@NonNull Menu menu) {
        getMenuInflater().inflate(R.menu.menu_list_view, menu);
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.about_menu:
                openAboutActivity(findViewById(R.id.about_menu));
                return true;
            case R.id.edit_menu:
                openEditActivity(findViewById(R.id.edit_menu));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public ArrayList<Note> loadJSONFile() {

        Log.d(TAG, "loadJSONFile: Loading JSON File");
        try {
            InputStream is = getApplicationContext().openFileInput(getString(R.string.file_name));
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));

            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }

            JSONArray jsonArray = new JSONArray(sb.toString());
            for(int i= 0; i < jsonArray.length(); i++)
            {
                JSONObject jsonObject;
                jsonObject = jsonArray.getJSONObject(i);
                String title = jsonObject.getString("title");
                String detail = jsonObject.getString("detail");
                String date = jsonObject.getString("date");
                m_notesList.add(new Note(title,detail,date));
            }
        } catch (FileNotFoundException e) {

        } catch (Exception e) {
            Log.d(TAG, "loadData: " + e.getMessage());
            e.printStackTrace();
        }
        return m_notesList;
    }

    private void WriteToJSONFile() {

        Log.d(TAG, "SAVE_FILE: Saving JSON File");
        String output = toJSON(m_notesList);
        try {
            FileOutputStream fos = getApplicationContext().openFileOutput(getString(R.string.file_name), Context.MODE_PRIVATE);
            PrintWriter printWriter = new PrintWriter(fos);
            printWriter.print(output);
            printWriter.close();
            fos.close();
        } catch (Exception e) {
            e.getStackTrace();
        }
    }
    private void openAboutActivity(View viewById) {
        Intent intent = new Intent(this, AboutActivity.class);
        startActivity(intent);
    }
    public void openEditActivity(View view)
    {
        Intent intent = new Intent(this, EditActivity.class);
        activityResultLauncher.launch(intent);
    }

    @SuppressLint("DefaultLocale")

    protected void onPause() {
        Log.d(TAG, "onPause:");
        WriteToJSONFile();
        super.onPause();

    }
    @NonNull
    public String toJSON(ArrayList<Note> m_notesList) {

        try {
            StringWriter sw = new StringWriter();
            JsonWriter jsonWriter = new JsonWriter(sw);
            jsonWriter.setIndent("  ");

            jsonWriter.beginArray();
                for (Note n : m_notesList) {
                    jsonWriter.beginObject();
                    jsonWriter.name("title").value(n.getTitle());
                    jsonWriter.name("detail").value(n.getDetail());
                    jsonWriter.name("date").value(n.getMillis());
                    jsonWriter.endObject();
                }
            jsonWriter.endArray();
            jsonWriter.close();
            return sw.toString();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }

    @Override
    public void onClick(View view) {

        pos = recyclerView.getChildLayoutPosition(view);
        Note n = m_notesList.get(pos);
        Intent intent = new Intent(this, EditActivity.class);
        Bundle bundle = new Bundle();
        intent.putExtra("NOTE_OBJECT", n);
        intent.putExtra("EDIT_POS",pos);
        activityResultLauncher.launch(intent);
    }

    @Override
    public boolean onLongClick(View view) {
        pos = recyclerView.getChildLayoutPosition(view);
        Note n = m_notesList.get(pos);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getResources().getString(R.string.delete_note));
        builder.setMessage(getResources().getString(R.string.delete_note) + " '" + n.getTitle() + "'?");
        builder.setPositiveButton(R.string.yes_button, (dialog, id) -> {
            m_notesList.remove(pos);
            String app_name = getResources().getString(R.string.app_name);
            setTitle(app_name + " (" + m_notesList.size() + ")");
            n_Adapter.notifyDataSetChanged();
            Toast.makeText(this, "Note '" + n.getTitle() + "' Deleted!", Toast.LENGTH_SHORT).show();
        });
        builder.setNegativeButton(R.string.no_button, (dialog, id) -> {
            return;
        });
        AlertDialog dialog = builder.create();
        dialog.show();
        return false;
    }

    @SuppressLint("DefaultLocale")
    protected void onResume() {
        setTitle(String.format("Android Notes (%d)",m_notesList.size()));
        super.onResume();
    }
    @Override
    public void onRestart() {
        super.onRestart();
        if (getCurrentFocus() != null)
            getCurrentFocus().clearFocus();
    }
    public void onBackPressed()
    {
        finish();
        finishAffinity();
    }
}
