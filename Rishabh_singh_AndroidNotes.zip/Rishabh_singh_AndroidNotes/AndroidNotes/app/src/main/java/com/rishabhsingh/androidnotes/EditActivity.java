package com.rishabhsingh.androidnotes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class EditActivity extends AppCompatActivity {

    private EditText noteTitleId;
    private EditText editfieldId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        noteTitleId = findViewById(R.id.Text_Title);
        editfieldId = findViewById(R.id.Text_Data);

        Intent intent = getIntent();
        if (intent.hasExtra("TITLE")) {
            String noteTitle = intent.getStringExtra("NOTE_TITLE");
            noteTitleId.setText(String.format("%s", noteTitle));
        }
        if (intent.hasExtra("NOTE_CONTENT")) {
            String filedId = intent.getStringExtra("NOTE_CONTENT");
            editfieldId.setText(String.format("%s", filedId));
        }
        if(intent.hasExtra("NOTE_OBJECT"))
        {
            Note oNote = (Note) intent.getSerializableExtra("NOTE_OBJECT");
            noteTitleId.setText(String.format("%s", oNote.getTitle()));
            editfieldId.setText(String.format("%s", oNote.getDetail()));
        }
    }
    @Override
    public boolean onCreateOptionsMenu(@NonNull Menu menu) {
        getMenuInflater().inflate(R.menu.menu_edit_view, menu);
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.save_menu:
                Save(findViewById(R.id.save_menu));
                Toast.makeText(this,"Your Note has been saved",Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public void Save(View v) {

        String noteTitle = noteTitleId.getText().toString();
        String fieldId = editfieldId.getText().toString();
        Date date = new Date();
        @SuppressLint("SimpleDateFormat") SimpleDateFormat dateFormat = new SimpleDateFormat("E MMM dd',' yyyy hh:mm:ss a ");
        String millis = dateFormat.format(date);
        if(noteTitle.isEmpty())
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                }
            });
            builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    EditActivity.super.onBackPressed();

                }
            });
            builder.setTitle("No Title Found");
            builder.setMessage("Want to Go back to Edit Note Title?");

            AlertDialog dialog = builder.create();
            dialog.show();
        }
        else {
            String fkey = "NOTE_OBJECT_NEW";

            Intent intent = getIntent();
            if (intent.hasExtra("NOTE_OBJECT")) {
                fkey = "NOTE_OBJECT_UPDATED";
            }

            Note oNote = new Note(noteTitle,fieldId,millis);
            Intent data = new Intent();
            data.putExtra(fkey, oNote);
            if (intent.hasExtra("EDIT_POS")) {
                int pos = intent.getIntExtra("EDIT_POS", 0);
                data.putExtra("UPDATE_POS", pos);
            }
            setResult(RESULT_OK, data);
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setPositiveButton("YES", (dialogInterface, i) -> Save(null));
        builder.setNegativeButton("NO", (dialogInterface, i) -> EditActivity.super.onBackPressed());
        builder.setTitle("The changes will not be Saved !");
        builder.setMessage("Please save Note before Exiting !");
        AlertDialog dialog = builder.create();
        dialog.show();

    }

}