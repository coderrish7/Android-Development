package com.rishabhsingh.androidnotes;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<ViewHolder> {

    private final List<Note> nList;
    private final MainActivity mainAct;

    Adapter(List<Note> empList, MainActivity ma) {
        this.nList = empList;
        mainAct = ma;
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.titleNote.setText(nList.get(position).getTitle());
        String detail = nList.get(position).getDetail();
        detail=detail.replaceAll("\n"," ");

        if(detail.length()>80) holder.detailNotes.setText(detail.substring(0, 80) + "...");
        else{
            holder.detailNotes.setText(detail);
        }
        holder.noteDate.setText(nList.get(position).getMillis());
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_view, parent, false);

        itemView.setOnClickListener(mainAct);
        itemView.setOnLongClickListener(mainAct);
        return new ViewHolder(itemView);
    }

    @Override
    public int getItemCount() {
        return nList.size();
    }
}
