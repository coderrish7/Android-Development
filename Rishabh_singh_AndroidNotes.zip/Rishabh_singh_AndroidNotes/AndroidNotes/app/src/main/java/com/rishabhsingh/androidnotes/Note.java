package com.rishabhsingh.androidnotes;


import android.util.JsonWriter;

import androidx.annotation.NonNull;

import java.io.IOException;
import java.io.Serializable;
import java.io.StringWriter;

public class Note implements Serializable {

    private String title;
    private String detail;
    private String millis;

    public Note (String title, String detail ,String millis) {
        this.title = title;
        this.detail = detail;
        this.millis = millis;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getMillis() {
        return millis;
    }

    @NonNull
    @Override
    public String toString() {

        try {
            StringWriter stringWriter = new StringWriter();
            JsonWriter jsonWriter = new JsonWriter(stringWriter);
            jsonWriter.setIndent("  ");
            jsonWriter.beginObject();
            jsonWriter.name("title").value(getTitle());
            jsonWriter.name("detail").value(getDetail());
            jsonWriter.name("date").value(getMillis());
            jsonWriter.endObject();
            jsonWriter.close();
            return stringWriter.toString();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";

    }
}
