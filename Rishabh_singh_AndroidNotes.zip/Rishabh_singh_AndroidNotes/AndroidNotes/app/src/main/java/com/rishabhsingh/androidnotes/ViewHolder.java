package com.rishabhsingh.androidnotes;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ViewHolder extends RecyclerView.ViewHolder{

    TextView titleNote;
    TextView noteDate;
    TextView detailNotes;

    public ViewHolder(@NonNull View itemView) {
        super(itemView);
        titleNote = itemView.findViewById(R.id.note_title);
        noteDate = itemView.findViewById(R.id.note_date);
        detailNotes = itemView.findViewById(R.id.note_data);
    }
}
