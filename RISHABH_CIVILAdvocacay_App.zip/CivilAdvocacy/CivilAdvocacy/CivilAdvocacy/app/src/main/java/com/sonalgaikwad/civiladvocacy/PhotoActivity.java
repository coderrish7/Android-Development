package com.sonalgaikwad.civiladvocacy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class PhotoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo);
        ImageView photoOfficial = findViewById(R.id.photoOfficial);
        ImageView partyLogoOfficial = findViewById(R.id.partyLogoOfficial);
        TextView location_display = findViewById(R.id.location_display);
        TextView TitleOfficial = findViewById(R.id.TitleOfficial);
        TextView NameOfficial = findViewById(R.id.NameOfficial);

        Picasso picasso = Picasso.get();

        Intent intent = getIntent();
        Official oOfficial = (Official) intent.getSerializableExtra("official");
        CharSequence ch = intent.getCharSequenceExtra("location");
        if (ch == null)
            Log.d("ch", "null");
        else
            Log.d("ch", ch.toString());

        location_display.setText(intent.getCharSequenceExtra("location"));
        TitleOfficial.setText(oOfficial.getTitle());
        NameOfficial.setText(oOfficial.getName());

        if (oOfficial.getPhotoURL() != null) {
            picasso.load(oOfficial.getPhotoURL().replace("http:", "https:")).error(R.drawable.brokenimage)
                    .placeholder(R.drawable.missing).into(photoOfficial);
        } else {
            picasso.load(oOfficial.getPhotoURL()).error(R.drawable.brokenimage)
                    .placeholder(R.drawable.missing).into(photoOfficial);
        }

        if (oOfficial.getParty() != null)
        {
            if (oOfficial.getParty().contains("Republican")) {
                getWindow().getDecorView().setBackgroundColor(Color.RED);
                partyLogoOfficial.setImageResource(R.drawable.rep_logo);
            } else if (oOfficial.getParty().contains("Democratic")) {
                getWindow().getDecorView().setBackgroundColor(Color.BLUE);
                partyLogoOfficial.setImageResource(R.drawable.dem_logo);
            } else if(oOfficial.getParty().contains("Nonpartisan")) {
                getWindow().getDecorView().setBackgroundColor(Color.BLACK);
                partyLogoOfficial.setImageResource(R.drawable.non_logo);

            }
            else {
                getWindow().getDecorView().setBackgroundColor(Color.BLACK);
                partyLogoOfficial.setVisibility(View.INVISIBLE);
            }
        }
    }
}