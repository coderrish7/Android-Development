package com.sonalgaikwad.civiladvocacy;

import static android.content.pm.PackageManager.PERMISSION_GRANTED;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "MainActivity";
    private final ArrayList<Official> officialList = new ArrayList<Official>();
    private RecyclerView oRecyclerView;
    static MainActivity oMainActivity;

    private TextView locationText;
    private TextView location_warning;
    OfficialAdapter oOfficialAdapter;

    private String currentLocation;
    private String geoLatLong;

    private LocationManager locationManager;
    private Criteria criteria;

    private static final int LOCATION_REQUEST = 329;
    private SwipeRefreshLayout swiperLayout;

    private FusedLocationProviderClient mFusedLocationClient;
    private String locationString = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        swiperLayout = findViewById(R.id.swiperlayout);
        oMainActivity = this;
        oRecyclerView = findViewById(R.id.recycler_view);
        locationText = findViewById(R.id.location_bar);
        location_warning = findViewById(R.id.locationWarning);
        currentLocation = "";
        geoLatLong = "";

        swiperLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mFusedLocationClient =
                        LocationServices.getFusedLocationProviderClient(oMainActivity);
                currentLocation = determineLocation();

                if (!currentLocation.equals("")) {
                    if (checkNetwork()) {
                        new DataLoader(MainActivity.this).execute(currentLocation);
                    } else {
                        setupNetworkDialog(getString(R.string.networkError1));
                    }
                }
                else {
                    if(!checkLocationSetting())
                        setupLocationDialog(getString(R.string.locationError1), 0);
                }

                swiperLayout.setRefreshing(false);
            }
        });


        //location_setup();
        //getLocation();
        mFusedLocationClient =
                LocationServices.getFusedLocationProviderClient(oMainActivity);
        currentLocation = determineLocation();

        //currentLocation = "chicago";
        //geoLatLong = "60616";
        oOfficialAdapter = new OfficialAdapter(officialList, this);
        oRecyclerView.setAdapter(oOfficialAdapter);
        oRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        if (!currentLocation.equals("")) {
            if (checkNetwork()) {
                new DataLoader(MainActivity.this).execute(currentLocation);
            } else {
                setupNetworkDialog(getString(R.string.networkError1));
            }
        }
    }

    private boolean checkAppPermissions() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION
                    }, LOCATION_REQUEST);
            return false;
        }
        return true;
    }

    private String getPlace(Location loc) {

        StringBuilder sb = new StringBuilder();

        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        List<Address> addresses;
        String addressLine = "";

        try {
            addresses = geocoder.getFromLocation(loc.getLatitude(), loc.getLongitude(), 1);
            if(addresses.size() > 0)
                addressLine = addresses.get(0).getAddressLine(0);
            else {
                if(checkLocationSetting())
                    setupLocationDialog(getString(R.string.locationError1), 0);

                //addressLine = "Chicago";
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return addressLine;
    }

    @SuppressLint("MissingPermission")
    private String determineLocation() {
        if (checkAppPermissions()) {
            mFusedLocationClient.getLastLocation()
                    .addOnSuccessListener(this, location -> {
                        // Got last known location. In some situations this can be null.
                        if (location != null) {
                            locationString = getPlace(location);
                            currentLocation = locationString;

                            new DataLoader(MainActivity.this).execute(currentLocation);
                        }
                    })
                    .addOnFailureListener(this, e -> Toast.makeText(MainActivity.this,
                            e.getMessage(), Toast.LENGTH_LONG).show());
            return locationString;
        }
        return locationString;
    }


    public boolean checkLocationSetting() {
        int locationCheck;
        try {
            locationCheck = Settings.Secure.getInt(getApplicationContext().getContentResolver(), Settings.Secure.LOCATION_MODE);
        } catch (Settings.SettingNotFoundException e) {
            e.printStackTrace();
            return false;
        }
        return locationCheck != Settings.Secure.LOCATION_MODE_OFF;
    }

    public void openAboutActivity(MenuItem item){
        try {
            Intent intent = new Intent(this, AboutActivity.class);
            startActivity(intent);
        }catch (Exception e) {
            e.printStackTrace();
            Log.d(TAG, "onCreate: " + e);
        }
    }

    public void setupNetworkDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setIcon(R.drawable.ic_baseline_error);
        builder.setTitle(R.string.networkError0);
        builder.setMessage(message);
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_items, menu);
        return true;
    }

    public void setSearchDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final EditText edittext = new EditText(this);
        edittext.setGravity(Gravity.CENTER_HORIZONTAL);
        builder.setView(edittext);
        builder.setIcon(R.drawable.ic_search_accent);

        builder.setPositiveButton("Search", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                String searchString = edittext.getText().toString().trim();
                if (!searchString.equals("")) {
                    locationText.setText(searchString);
                    new DataLoader(MainActivity.this).execute(searchString);
                } else {
                    Toast.makeText(MainActivity.this, R.string.nullStringMsg, Toast.LENGTH_SHORT).show();
                    setSearchDialog();
                }

            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
            }
        });

        builder.setMessage(R.string.searchMessage);
        builder.setTitle(R.string.searchTitle);
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_location:
                if (checkNetwork()) {
                    setSearchDialog();
                } else
                    setupNetworkDialog(getString(R.string.networkError2));
                break;
            case R.id.menu_about:
                openAboutActivity(item);
                break;
            default:
                Toast.makeText(this, "Invalid Option", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_REQUEST) {
            if (permissions[0].equals(Manifest.permission.ACCESS_FINE_LOCATION) && grantResults[0] == PERMISSION_GRANTED) {
                mFusedLocationClient =
                        LocationServices.getFusedLocationProviderClient(oMainActivity);
                currentLocation = determineLocation();
                if (!currentLocation.equals("")) {
                    if (checkNetwork()) {
                        new DataLoader(MainActivity.this).execute(currentLocation);
                    } else {
                        setupNetworkDialog(getString(R.string.networkError1));
                    }
                }
                else
                    setupLocationDialog("Location unavailable", 1);


                return;
            }
        }
        setupLocationDialog(getString(R.string.locationError1), 0);
        locationText.setText(R.string.no_permission);
    }

    public void updateOfficialData(ArrayList<Official> officalList) {
        officialList.clear();
        if (officalList.size() != 0) {
            officialList.addAll(officalList);
            location_warning.setVisibility(View.GONE);
        } else {
            if(!checkLocationSetting())
            {locationText.setText(getText(R.string.no_location_warning));
            location_warning.setVisibility(View.VISIBLE);}
            else
            {

            }
        }
        oOfficialAdapter.notifyDataSetChanged();
    }


    public void setupLocationDialog(String message, int dismissFlag) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        AlertDialog alertDialog = builder.create();
        if (dismissFlag == 0) {
            builder.setIcon(R.drawable.ic_baseline_error);
            builder.setTitle(R.string.locationError0);
            builder.setMessage(message);
            alertDialog = builder.create();
            alertDialog.show();
        } else if (dismissFlag == 1)
            alertDialog.dismiss();
    }

    public Boolean checkNetwork()
    {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo !=null && networkInfo.isConnectedOrConnecting())
            return true;
        else
            return false;
    }

    @Override
    protected void onPause() {
        super.onPause();
    }


    @Override
    public void onClick(View view) {
        int position = oRecyclerView.getChildAdapterPosition(view);
        Official temp = officialList.get(position);
        Intent i = new Intent(this, OfficialActivity.class);
        i.putExtra("location", locationText.getText());
        i.putExtra("official", temp);
         startActivity(i);
    }
}