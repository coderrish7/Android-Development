package com.sonalgaikwad.civiladvocacy;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class OfficialAdapter  extends RecyclerView.Adapter<OfficialAdapter.OfficialViewHolder>{

    private List<Official> officialList;
    private MainActivity oMainActivity;

    public OfficialAdapter(ArrayList<Official> officialList, MainActivity oMainActivity) {
        this.oMainActivity = oMainActivity;
        this.officialList = officialList;
    }

    @NonNull
    @Override
    public OfficialViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_entry,parent,false);
        itemView.setOnClickListener(oMainActivity);
        return new OfficialViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull OfficialViewHolder holder, int position) {
        Official tempOfficial = officialList.get(position);
        Picasso picasso = Picasso.get();
        try {
            picasso.load(tempOfficial.getPhotoURL().replace("http:", "https:")) .error(R.drawable.missing)
                    .placeholder(R.drawable.missing).into(holder.imageViewOfficial);

        } catch (IllegalArgumentException ae) {
            Picasso.get().load(R.drawable.missing).into(holder.imageViewOfficial);
        }
        holder.officialTitle.setText(tempOfficial.getTitle());
        holder.officialName.setText(tempOfficial.getName());
        holder.officialParty.setText(tempOfficial.getParty());
    }

    @Override
    public int getItemCount() {
        return officialList.size();
    }

    static class OfficialViewHolder extends RecyclerView.ViewHolder {
        private ImageView imageViewOfficial;
        private TextView officialTitle;
        private TextView officialName;
        private TextView officialParty;

        public OfficialViewHolder(@NonNull View itemView) {
            super(itemView);
            imageViewOfficial = itemView.findViewById(R.id.imageViewOfficial);
            officialTitle = itemView.findViewById(R.id.officialTitle);
            officialName = itemView.findViewById(R.id.OfficialName);
            officialParty = itemView.findViewById(R.id.OfficialParty);
        }
    }

}
