package com.sonalgaikwad.civiladvocacy;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.util.Linkify;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class OfficialActivity extends AppCompatActivity {
    private static final String TAG = OfficialActivity.class.getName();

    private ConstraintLayout constraintLayout;
    private ConstraintLayout detailsSection;

    private TextView officialTitle;
    private TextView official_name;
    private TextView official_party;
    private TextView addressTextView;
    private TextView addrressTextLabel;
    private TextView emailTextView;
    private TextView emailTextLabel;
    private TextView urlTextView;
    private TextView urlTextLabel;
    private TextView phoneTextView;
    private TextView phoneTextLabel;
    private TextView locationToolBar;

    private ImageView profile_picture;
    private ImageView partyImage;
    private ImageView facebookImage;
    private ImageView twitterImage;
    private ImageView youtubeImage;

    private Channel fbHandle;
    private Channel twitterHandle;
    private Channel youtubeHandle;

    private Official oOfficial;


    private static final String dem = "https://democrats.org";
    private static final String rep = "https://www.gop.com";


    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_official);

        loadUI();
        updateLocation();
        Intent intent = getIntent();
        locationToolBar.setText(intent.getCharSequenceExtra("location"));
        oOfficial = (Official) intent.getSerializableExtra("official");
        addressTextView.setText(oOfficial.getAddress());
        if (oOfficial.getTitle() != null)
            officialTitle.setText(oOfficial.getTitle());
        official_name.setText(oOfficial.getName());

        Picasso picasso = Picasso.get();

        if (oOfficial.getParty() != null) {

            if (oOfficial.getParty().contains("Republican")){
                getWindow().getDecorView().setBackgroundColor(Color.RED);
                official_party.setText(oOfficial.getParty());
                official_party.setTextColor(Color.WHITE);
                partyImage.setImageResource(R.drawable.rep_logo);
            }
            else if (oOfficial.getParty().contains("Democratic")) {
                official_party.setText(oOfficial.getParty());
                getWindow().getDecorView().setBackgroundColor(Color.BLUE);
                partyImage.setImageResource(R.drawable.dem_logo);
            }
            else if(oOfficial.getParty().contains("Nonpartisan")){
                getWindow().getDecorView().setBackgroundColor(Color.BLACK);
                partyImage.setImageResource(R.drawable.non_logo);
                official_party.setText(oOfficial.getParty());

            }
        } else getWindow().getDecorView().setBackgroundColor(Color.BLACK);

        if (oOfficial.getAddress() != null) {
            addressTextView.setText(oOfficial.getAddress().trim());
            Linkify.addLinks(addressTextView, Linkify.ALL);
            addressTextView.setLinkTextColor(getColor(R.color.white));
        } else {
            addrressTextLabel.setVisibility(View.GONE);
            addressTextView.setVisibility(View.GONE);
            ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, 0, 0, 0);
            phoneTextLabel.setLayoutParams(params);
        }


        if (oOfficial.getPhones() != null)
            phoneTextView.setText(oOfficial.getPhones());
        else
        {
            phoneTextLabel.setVisibility(View.GONE);
           // phoneTextView.setText("No phoneTextView provided");
            phoneTextView.setVisibility(View.GONE);
        }

        if (oOfficial.getEmails() != null) {
            emailTextView.setText(oOfficial.getEmails());
        }
        else {
            //emailTextView.setText("No Email provided");
            //emailTextView.setTextColor(android.R.color.white);
            emailTextView.setVisibility(View.INVISIBLE);
            emailTextLabel.setVisibility(View.INVISIBLE);
        }

        if (oOfficial.getUrls() != null)
            urlTextView.setText(oOfficial.getUrls());
        else {
            urlTextLabel.setVisibility(View.GONE);
           // urlTextView.setVisibility(View.GONE);
            urlTextView.setText("No URL provided");
        }


        if (oOfficial.getPhotoURL() != null){
            try {
                picasso.load(oOfficial.getPhotoURL().replace("http:", "https:")).error(R.drawable.brokenimage)
                        .placeholder(R.drawable.missing).into(profile_picture);
            }
            catch (Exception e)
            {
                picasso.load(R.drawable.missing) .into(profile_picture);
            }
        }
        else
        {
            picasso.load(oOfficial.getPhotoURL()) .error(R.drawable.brokenimage)
                    .placeholder(R.drawable.missing) .into(profile_picture);
        }

        if (oOfficial.getoChannelList() == null) {
            facebookImage.setVisibility(View.INVISIBLE);
            youtubeImage.setVisibility(View.INVISIBLE);
            twitterImage.setVisibility(View.INVISIBLE);
        }
        else
        {
            ArrayList<Channel> channelModels = oOfficial.getoChannelList();
            if (channelModels.size() > 0)
            {
                for (Channel single_channelModel : channelModels) {
                    if (single_channelModel.getType().equals("Facebook")) {
                        fbHandle = single_channelModel;
                        facebookImage.setVisibility(View.VISIBLE);

                    }
                    if (single_channelModel.getType().equals("Twitter")) {
                        twitterHandle = single_channelModel;
                        twitterImage.setVisibility(View.VISIBLE);

                    }

                    if (single_channelModel.getType().equals("YouTube")) {
                        youtubeHandle = single_channelModel;
                        youtubeImage.setVisibility(View.VISIBLE);
                    }
                }
            }

        }

        Linkify.addLinks(urlTextView, Linkify.ALL);
        Linkify.addLinks(addressTextView, Linkify.ALL);
        Linkify.addLinks(emailTextView, Linkify.ALL);
        Linkify.addLinks(phoneTextView, Linkify.ALL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    void loadUI() {
        constraintLayout = findViewById(R.id.constraintLayout);
        detailsSection = findViewById(R.id.detailsSection);

        locationToolBar = findViewById(R.id.locationToolBar);
        officialTitle = findViewById(R.id.official_Title);
        official_name = findViewById(R.id.official_name);
        official_party = findViewById(R.id.official_party);
        addrressTextLabel = findViewById(R.id.addrressTextLabel);
        addressTextView = findViewById(R.id.addressTextView);
        emailTextLabel = findViewById(R.id.emailTextLabel);
        emailTextView = findViewById(R.id.emailTextView);
        urlTextLabel = findViewById(R.id.urlTextLabel);
        urlTextView = findViewById(R.id.urlTextView);
        phoneTextLabel = findViewById(R.id.phoneTextLabel);
        phoneTextView = findViewById(R.id.phoneTextView);

        profile_picture = findViewById(R.id.profile_picture);
        partyImage = findViewById(R.id.partyImage);

        facebookImage = findViewById(R.id.facebookImage);
        twitterImage = findViewById(R.id.twitterImage);
        youtubeImage = findViewById(R.id.youtubeImage);

    }

    void updateLocation() {
        if (getIntent().hasExtra("locationToolBar"))
            locationToolBar.setText(getIntent().getStringExtra("locationToolBar"));
        else
            locationToolBar.setText("");
    }


    public void onProfileImageClick(View v) {
        if (!oOfficial.getPhotoURL().equals("")) {
            Intent i = new Intent(this, PhotoActivity.class);
            i.putExtra("location", locationToolBar.getText());
            i.putExtra("official", oOfficial);
            startActivity(i);
        } else
            Toast.makeText(this, "No Profile Picture Available", Toast.LENGTH_SHORT).show();

    }

    public void onPartyLogoClicked(View v) {
        String demUrl = "https://democrats.org";
        String repUrl = "https://www.gop.com";
        if (oOfficial.getParty().toLowerCase().trim().contains("democratic")) {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(demUrl));
            startActivity(i);
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        } else if (oOfficial.getParty().toLowerCase().trim().contains("republican")) {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(repUrl));
            startActivity(i);
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        }
    }

    public void onTwitterClicked(View v) {
        Intent intent;
        String id = twitterHandle.getId();
        try {
            getPackageManager().getPackageInfo("com.twitter.android", 0);
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("twitter://user?screen_name=" + id));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        } catch (Exception e) {
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/" + id));
        }
        startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    public void onFacebookImageClicked(View v) {
        String id = fbHandle.getId();
        String facebookUrl = "https://www.facebook.com/" + id;
        String url;
        PackageManager packageManager = getPackageManager();
        try {
            int versionCode = packageManager.getPackageInfo("com.facebook.katana", 0).versionCode;
            if (versionCode >= 3002850) { //newer versions of fb app
                url = "fb://facewebmodal/f?href=" + facebookUrl;
            } else { //older versions of fb app
                url = "fb://page/" + id;
            }
        } catch (PackageManager.NameNotFoundException e) {
            url = facebookUrl; //normal web urlTextView
        }
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }


    public void youTubeClicked(View v) {
        String id = youtubeHandle.getId();
        Intent intent;
        try {
            intent = new Intent(Intent.ACTION_VIEW);
            intent.setPackage("com.google.android.youtube");
            intent.setData(Uri.parse("https://www.youtube.com/" + id));
            startActivity(intent);
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/" + id)));
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        }
    }

}