package com.sonalgaikwad.civiladvocacy;

import java.io.Serializable;
import java.util.ArrayList;

public class Official implements Serializable {
     private String name;
     private String title;
     private String address;
     private String party;
     private String phones;
     private String urls;
     private String emails;
     private String photoURL;

     private ArrayList<Channel> oChannelList;

     public Official() {
          name = "";
          title = "";
          address = "";
          party = "";
          phones = "";
          urls = "";
          emails = "";
          photoURL = "";
          oChannelList = new ArrayList<>();
     }

     public String getName() {
          return name;
     }

     public String getTitle() {
          return title;
     }

     public String getAddress() {
          return address;
     }

     public String getParty() {
          return party;
     }

     public String getPhones() {
          return phones;
     }

     public String getUrls() {
          return urls;
     }

     public String getEmails() {
          return emails;
     }

     public String getPhotoURL() {
          return photoURL;
     }
     public ArrayList<Channel> getoChannelList() {
          return oChannelList;
     }

     public void setName(String name) {
          this.name = name;
     }

     public void setTitle(String title) {
          this.title = title;
     }

     public void setAddress(String address) {
          this.address = address;
     }

     public void setParty(String party) {
          this.party = party;
     }

     public void setPhones(String phones) {
          this.phones = phones;
     }

     public void setUrls(String urls) {
          this.urls = urls;
     }

     public void setEmails(String emails) {
          this.emails = emails;
     }

     public void setPhotoURL(String photoURL) {
          this.photoURL = photoURL;
     }

     public void setoChannelList(ArrayList<Channel> oChannelList) {
          this.oChannelList = oChannelList;
     }
}
