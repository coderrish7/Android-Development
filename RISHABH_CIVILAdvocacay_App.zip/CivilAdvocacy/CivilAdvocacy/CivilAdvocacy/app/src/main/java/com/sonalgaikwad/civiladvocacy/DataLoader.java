package com.sonalgaikwad.civiladvocacy;

import android.annotation.SuppressLint;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class DataLoader extends AsyncTask<String, Void, ArrayList<Official>>
{
    @SuppressLint("StaticFieldLeak")
    private MainActivity m_oMainActivity;
    private static final String TAG = "DataLoader";
   // private String URLprefix = "https://www.googleapis.com/civicinfo/v2/representatives?key=AIzaSyCM6LGKdjAoe7h7r6MKjXsLe_mXx1Gu5sg&address=";

    public DataLoader(MainActivity oMainActivity) {
        this.m_oMainActivity = oMainActivity;
    }

    private String extractURLData(String Url) {
        Uri dataUri = Uri.parse(Url);
        String urlString = dataUri.toString();

        StringBuilder sb = new StringBuilder();
        try {
            java.net.URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            conn.setRequestMethod("GET");
            InputStream is = conn.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));
            String line;
            while ((line = reader.readLine()) != null)
                sb.append(line).append('\n');
        } catch (Exception e) {
            Log.e(TAG, "EXCEPTION", e);
            return sb.toString();
        }
        return sb.toString();
    }

    @Override
    protected ArrayList<Official> doInBackground(String... strings)
    {
        String locationString = strings[0];

        if(locationString.length() > 20)
        {
            int index = locationString.lastIndexOf(',');
            locationString = locationString.substring(0, index);
            index = locationString.lastIndexOf(',');
            locationString = locationString.substring(index+1);
            locationString = locationString.trim();
            index = locationString.lastIndexOf(" ");
            locationString = locationString.substring(index+1);
        }
        String setLocation = "";
        if(strings.length > 1) {
            setLocation = strings[1];
        }

        String apiKey = "AIzaSyCM6LGKdjAoe7h7r6MKjXsLe_mXx1Gu5sg";
        String URL = "https://www.googleapis.com/civicinfo/v2/representatives?key=" + apiKey + "&address=" + locationString;

        String fetcheddata = extractURLData(URL);
        ArrayList<Official> officialList;
        officialList = parseJson(fetcheddata);
        return officialList;
    }


    private String extractName(JSONObject jsonObject) {
        String name = "";
        try {
            name = jsonObject.getString("name");
        } catch (Exception e) {
            Log.d(TAG, "EXCEPTION " + e);
        }
        return name;
    }

    private String extractAddress(JSONObject jsonObject) {
        String finalAddress = "";
        try {
            JSONArray addressList = (JSONArray) jsonObject.get("address");
            JSONObject address = (JSONObject) addressList.get(0);
            String zip = extractZIPData(address);
            String state = extractStateData(address);
            String city = extractCityData(address);
            String line1 = extractLine1Data(address);
            String line2 = extractLine2Data(address);
            finalAddress = line1 + ", " + (line2.equals("") ? line2 + "" : line2 + ", ") + city + ", " + state + ", " + zip;
        } catch (Exception e) {
            Log.d(TAG, "EXCEPTION " + e);
        }

        return finalAddress;
    }

    private String extractZIPData(JSONObject jsonObject) {
        String zip = "";
        try {
            zip = jsonObject.getString("zip");
        } catch (Exception e) {
            Log.d(TAG, "EXCEPTION " + e);
        }
        return zip;
    }

    private String extractLine1Data(JSONObject jsonObject) {
        String line1 = "";
        try {
            line1 = jsonObject.getString("line1");
        } catch (Exception e) {
            Log.d(TAG, "EXCEPTION " + e);
        }
        return line1;
    }

    private String extractLine2Data(JSONObject jsonObject) {
        String line2 = "";
        try {
            line2 = jsonObject.getString("line2");
        } catch (Exception e) {
            Log.d(TAG, "EXCEPTION " + e);
        }
        return line2;
    }

    private String extractCityData(JSONObject jsonObject) {
        String city = "";
        try {
            city = jsonObject.getString("city");
        } catch (Exception e) {
            Log.d(TAG, "EXCEPTION " + e);
        }
        return city;
    }

    private String extractStateData(JSONObject jsonObject) {
        String state = "";
        try {
            state = jsonObject.getString("state");
        } catch (Exception e) {
            Log.d(TAG, "EXCEPTION " + e);
        }
        return state;
    }


    private String extractURL(JSONObject jsonObject) {
        String urlString = "";
        try {
            JSONArray urls = (JSONArray) jsonObject.get("urls");
            urlString = urls.get(0).toString();
        } catch (Exception e) {
            Log.d(TAG, "EXCEPTION " + e);
        }
        return urlString;
    }

    private String extractEmail(JSONObject jsonObject) {
        String email = "";
        try {
            JSONArray urls = (JSONArray) jsonObject.get("emails");
            email = urls.get(0).toString();
        } catch (Exception e) {
            Log.d(TAG, "EXCEPTION " + e);
        }

        return email.toLowerCase();
    }

    private String extractPhone(JSONObject jsonObject) {
        String phone = "";
        try {
            JSONArray urls = (JSONArray) jsonObject.get("phones");
            phone = urls.get(0).toString();
        } catch (Exception e) {
            Log.d(TAG, "EXCEPTION " + e);
        }
        return phone;
    }

    private String extractParty(JSONObject jsonObject) {
        String party = "";
        try {
            party = jsonObject.getString("party");
        } catch (Exception e) {
            Log.d(TAG, "EXCEPTION " + e);
        }
        return "( " + party + " )";
    }

    private ArrayList<Channel> extractChannelList(JSONObject jsonObject) {
        ArrayList<Channel> tempList = new ArrayList<>();
        Channel temp;
        try {
            JSONArray channels = (JSONArray) jsonObject.get("channels");
            for (int i = 0; i < channels.length(); i++) {
                JSONObject channel = (JSONObject) channels.get(i);
                temp = new Channel(channel.getString("type"), channel.getString("id"));
                tempList.add(temp);
            }
        } catch (Exception e) {
            Log.d(TAG, "EXCEPTION " + e);
        }
        return tempList;
    }


    private String extractPhotoUrl(JSONObject jsonObject) {
        String photoURL = "";

        try {
            photoURL = jsonObject.getString("photoUrl");
        } catch (Exception e) {
            Log.d(TAG, "EXCEPTION " + e);
        }
        return photoURL;
    }


    private Official extractOfficialInfo(JSONObject jsonObject) {
        Official tempOfficial = new Official();
        tempOfficial.setName(extractName(jsonObject));
        tempOfficial.setParty(extractParty(jsonObject));
        tempOfficial.setAddress(extractAddress(jsonObject));
        tempOfficial.setUrls(extractURL(jsonObject));
        tempOfficial.setEmails(extractEmail(jsonObject));
        tempOfficial.setPhones(extractPhone(jsonObject));
        tempOfficial.setPhotoURL(extractPhotoUrl(jsonObject));
        tempOfficial.setoChannelList(extractChannelList(jsonObject));
        return tempOfficial;
    }


    private void extractLocation(String data) {
        TextView location = m_oMainActivity.findViewById(R.id.location_bar);
        try {
            JSONObject normalizedInput = new JSONObject(data);
            normalizedInput = normalizedInput.getJSONObject("normalizedInput");
            String city = normalizedInput.getString("city");
            String state = normalizedInput.getString("state");
            String zip = normalizedInput.getString("zip");

            String locationTemp = (city.equals("") ? "" : city + ", ") + (zip.equals("") ? state : state + ", ") + (zip.equals("") ? "" : zip);
            location.setText(locationTemp);
        } catch (Exception e) {
            Log.d(TAG, "EXCEPTION " + e);
        }
    }

    private ArrayList<Official> parseJson(String data) {
        ArrayList<Official> tempOfficialList = new ArrayList<>();
        extractLocation(data);
        Official officialModel;
        try {
            JSONObject temp = new JSONObject(data);
            JSONArray officials = (JSONArray) temp.get("officials");
            JSONArray offices = (JSONArray) temp.get("offices");

            for (int i = 0; i < offices.length(); i++) {
                JSONObject office = (JSONObject) offices.get(i);
                JSONObject officialIndices = (JSONObject) offices.get(i);
                JSONArray index = officialIndices.getJSONArray("officialIndices");

                for (int j = 0; j < index.length(); j++) {
                    Official tempOfficial;
                    JSONObject jsonObject = (JSONObject) officials.get(index.getInt(j));
                    tempOfficial = extractOfficialInfo(jsonObject);
                    officialModel = tempOfficial;
                    officialModel.setTitle(office.getString("name"));                    // Setting Title here because the above statement would nake the title field of official object to null string
                    tempOfficialList.add(officialModel);
                }
            }
        } catch (Exception e) {
            Log.d(TAG, "EXCEPTION" + e);
        }
        return tempOfficialList;
    }

    @Override
    protected void onPostExecute(ArrayList<Official> officialList) {
        m_oMainActivity.updateOfficialData(officialList);
        super.onPostExecute(officialList);
    }

}
