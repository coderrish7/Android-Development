package Model;

import com.rishabh_singh.civiladvocacy.Govtofficialdetail;

import java.io.Serializable;
import java.util.ArrayList;

public class Official implements Serializable {
     private String name;
     private String party;
     private String photoURL;
     private String address;
     private String phones;
     private String urls;
     private String emails;
     private String title;




     private ArrayList<Govtofficialdetail> govtofficialdetailArrayList;

     public Official() {
          this("", "", "", "", "", "", "", "");
     }

     public Official(String name, String title, String address, String party, String phones, String urls, String emails, String photoURL) {
          this.name = name;
          this.party = party;
          this.phones = phones;
          this.urls = urls;
          this.emails = emails;
          this.title = title;
          this.address = address;
          this.photoURL = photoURL;
          govtofficialdetailArrayList = new ArrayList<>();
     }

     public Official(String name, String title, String address, String party, String phones, String urls, String emails, String photoURL, ArrayList<Govtofficialdetail> oChannelList) {
          this(name, title, address, party, phones, urls, emails, photoURL);
          this.govtofficialdetailArrayList = oChannelList;
     }


     public String getName() {
          return name;
     }

     public String getTitle() {
          return title;
     }

     public String getAddress() {
          return address;
     }


     public String getEmails() {
          return emails;
     }
     public String getParty() {
          return party;
     }

     public String getPhones() {
          return phones;
     }

     public String getUrls() {
          return urls;
     }
     public String getPhotoURL() {
          return photoURL;
     }
     public ArrayList<Govtofficialdetail> getGovtofficialdetailArrayList() {
          return govtofficialdetailArrayList;
     }

     public void setName(String name) {
          this.name = name;
     }

     public void setTitle(String title) {
          this.title = title;
     }

     public void setAddress(String address) {
          this.address = address;
     }

     public void setParty(String party) {
          this.party = party;
     }

     public void setPhones(String phones) {
          this.phones = phones;
     }

     public void setUrls(String urls) {
          this.urls = urls;
     }

     public void setEmails(String emails) {
          this.emails = emails;
     }

     public void setPhotoURL(String photoURL) {
          this.photoURL = photoURL;
     }

     public void setGovtofficialdetailArrayList(ArrayList<Govtofficialdetail> govtofficialdetailArrayList) {
          this.govtofficialdetailArrayList = govtofficialdetailArrayList;
     }
}
