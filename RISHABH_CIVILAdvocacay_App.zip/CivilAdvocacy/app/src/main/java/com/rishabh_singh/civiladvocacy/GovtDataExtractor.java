package com.rishabh_singh.civiladvocacy;

import static com.rishabh_singh.civiladvocacy.MainActivity.mainActivity;

import android.annotation.SuppressLint;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import Model.Official;

public class GovtDataExtractor extends AsyncTask<String, Void, ArrayList<Official>>
{
    @SuppressLint("StaticFieldLeak")
    private final MainActivity activity;
    private static final String TAG = "Info-load";

    public GovtDataExtractor(MainActivity oMainActivity) {
        this.activity = oMainActivity;
    }

    private String extractURLData(String Url) {
        String result = null;
        Uri dataUri = Uri.parse(Url);
        String urlString = dataUri.toString();

        StringBuilder sb = new StringBuilder();
        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            conn.setRequestMethod("GET");
            InputStream is = conn.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));
            String line;
            while ((line = reader.readLine()) != null)
                sb.append(line).append('\n');
        } catch (Exception e) {
            Log.e(TAG, "EXCEPTION", e);
            result = sb.toString();
        }
        if (result == null) {
            result = sb.toString();
        }
        return result;
    }

    protected ArrayList<Official> doInBackground(String... strings) {
        String locationString = strings[0];

        if (locationString.length() > 20) {
            locationString = getLocationString(locationString);
        }

        String apiKey = "AIzaSyBuEI-kZCXt7jll2_agtPmXPyS6UbWR4E0";
        String urlTemplate = "https://www.googleapis.com/civicinfo/v2/representatives?key=%s&address=%s";
        String URL = String.format(urlTemplate, apiKey, locationString);


        String fetchedData = extractURLData(URL);

        if (fetchedData == null) {

            Toast.makeText(mainActivity, "Didn't get the API Response", Toast.LENGTH_SHORT).show();
            return null;
        }

        return parseJson(fetchedData);
    }

    private String getLocationString(String locationString) {
        int index = locationString.lastIndexOf(',');
        locationString = locationString.substring(0, index);
        index = locationString.lastIndexOf(',');
        locationString = locationString.substring(index+1);
        locationString = locationString.trim();
        index = locationString.lastIndexOf(" ");
        locationString = locationString.substring(index+1);

        return locationString;
    }



    private String extractOfficialAddress(JSONObject jsonObject) {
        String finalAddress = "";
        try {
            JSONArray addressList = (JSONArray) jsonObject.get("address");
            JSONObject address = (JSONObject) addressList.get(0);
            String zip = extractZipLocation(address);
            String state = extractstatedata(address);
            String city = extractcitydata(address);
            String line1 = extractLine1Data(address);
            String line2 = extractLine2Data(address);
            finalAddress = String.format("%s, %s%s, %s, %s", line1, line2.isEmpty() ? "" : line2 + ", ", city, state, zip);
        } catch (Exception e) {
            Log.d(TAG, "EXCEPTION " + e);
        }

        return finalAddress;
    }

    private String extractZipLocation(JSONObject jsonObject) {
        String zip = "";
        try {
            if (jsonObject.has("zip")) {
                zip = jsonObject.getString("zip");
            }
        } catch (Exception e) {
            Log.d(TAG, "EXCEPTION " + e);
        }
        return zip;
    }


    private String extractLine1Data(JSONObject jsonObject) {
        try {
            return jsonObject.getString("line1");
        } catch (JSONException e) {
            Log.e(TAG, "Error extracting line1 data", e);
            return "";
        }
    }

    private String extractOfficialName(JSONObject jsonObject) {
        String name = "";
        if (jsonObject != null) {
            try {
                name = jsonObject.getString("name");
            } catch (Exception e) {
                Log.d(TAG, "EXCEPTION " + e);
            }
        }
        return name;
    }
    private String extractLine2Data(JSONObject jsonObject) {
        try {
            return jsonObject.getString("line2");
        } catch (JSONException e) {
            Log.e(TAG, "Error extracting line2 data", e);
            return "";
        }
    }

        private String extractcitydata(JSONObject jsonObject) {
        String city = "";
        try {
            city = jsonObject.getString("city");
        } catch (Exception e) {
            Log.d(TAG, "EXCEPTION " + e);
        }
        return city;
    }

    private String extractstatedata(JSONObject jsonObject) {
        String state = "";
        try {
            state = jsonObject.getString("state");
        } catch (Exception e) {
            Log.d(TAG, "EXCEPTION " + e);
        }
        return state;
    }


    private String extractURL(JSONObject jsonObject) {
        String urlString = "";
        try {
            JSONArray urlArray = jsonObject.optJSONArray("urls");
            if (urlArray != null && urlArray.length() > 0) {
                urlString = urlArray.getString(0);
            } else {
                Log.d(TAG, "URL not found in JSON object");
            }
        } catch (JSONException e) {
            Log.d(TAG, "Error extracting URL from JSON data: " + e.getMessage());
        }
        return urlString;
    }

    private String extractEmail(JSONObject jsonObject) {
        String email = "";
        try {
            JSONArray emailArray = jsonObject.optJSONArray("emails");
            if (emailArray != null && emailArray.length() > 0) {
                email = emailArray.getString(0);
            } else {
                Log.d(TAG, "Email not found in JSON object");
            }
        } catch (JSONException e) {
            Log.d(TAG, "Error extracting email from JSON data: " + e.getMessage());
        }
        return email.toLowerCase();
    }

    private String extractPhonenumber(JSONObject jsonObject) {
        String phone = "";
        try {
            JSONArray urls = (JSONArray) jsonObject.get("phones");
            phone = urls.get(0).toString();
        } catch (Exception e) {
            Log.d(TAG, "EXCEPTION " + e);
        }
        return phone;
    }

    private String extractParty(JSONObject jsonObject) {
        String party = jsonObject.optString("party", "");
        if (party.isEmpty()) {
            Log.d(TAG, "Party not found in JSON object");
        }
        return "( " + party + " )";
    }


    private ArrayList<Govtofficialdetail> extractChannelList(JSONObject jsonObject) {
        ArrayList<Govtofficialdetail> tempList = new ArrayList<>();
        try {
            JSONArray channels = jsonObject.getJSONArray("channels");
            for (int i = 0; i < channels.length(); i++) {
                JSONObject channel = channels.getJSONObject(i);
                Govtofficialdetail detail = new Govtofficialdetail(channel.getString("type"), channel.getString("id"));
                tempList.add(detail);
            }
        } catch (JSONException e) {
            Log.e(TAG, "Error extracting channel list: " + e.getMessage());
        }
        return tempList;
    }



    private String extractPhotoUrl(JSONObject jsonObject) {
        String photoUrl = jsonObject.optString("photoUrl", "");
        if (photoUrl.isEmpty()) {
            Log.d(TAG, "Photo URL not found in JSON object");
        }
        return photoUrl;
    }


    private Official extractOfficialInfo(JSONObject jsonObject) {
        Official official = new Official();
        official.setName(extractOfficialName(jsonObject));
        official.setParty(extractParty(jsonObject));
        official.setAddress(extractOfficialAddress(jsonObject));
        official.setUrls(extractURL(jsonObject));
        official.setEmails(extractEmail(jsonObject));
        official.setPhones(extractPhonenumber(jsonObject));
        official.setPhotoURL(extractPhotoUrl(jsonObject));
        official.setGovtofficialdetailArrayList(extractChannelList(jsonObject));
        return official;
    }


    private void extractLocation(String data) {
        TextView location = activity.findViewById(R.id.location_title);
        try {
            JSONObject normalizedInput = new JSONObject(data)
                    .getJSONObject("normalizedInput");
            String city = normalizedInput.optString("city", "");
            String state = normalizedInput.optString("state", "");
            String zip = normalizedInput.optString("zip", "");

            String locationTemp = "";
            if (!city.isEmpty()) {
                locationTemp += city + ", ";
            }
            if (!zip.isEmpty()) {
                locationTemp += state + ", " + zip;
            } else {
                locationTemp += state;
            }
            location.setText(locationTemp);
        } catch (JSONException e) {
            Log.d(TAG, "Error extracting location from JSON data: " + e.getMessage());
        }
    }


    private ArrayList<Official> parseJson(String data) {
        ArrayList<Official> tempOfficialList = new ArrayList<>();
        extractLocation(data);
        Official officialModel;
        try {
            JSONObject temp = new JSONObject(data);
            JSONArray officials = (JSONArray) temp.get("officials");
            JSONArray offices = (JSONArray) temp.get("offices");

            for (int i = 0; i < offices.length(); i++) {
                JSONObject office = (JSONObject) offices.get(i);
                JSONObject officialIndices = (JSONObject) offices.get(i);
                JSONArray index = officialIndices.getJSONArray("officialIndices");

                for (int j = 0; j < index.length(); j++) {
                    Official tempOfficial;
                    JSONObject jsonObject = (JSONObject) officials.get(index.getInt(j));
                    tempOfficial = extractOfficialInfo(jsonObject);
                    officialModel = tempOfficial;
                    officialModel.setTitle(office.getString("name"));
                    tempOfficialList.add(officialModel);
                }
            }
        } catch (Exception e) {
            Log.d(TAG, "EXCEPTION" + e);
        }
        return tempOfficialList;
    }

    @Override
    protected void onPostExecute(ArrayList<Official> officialList) {
        activity.updateOfficialData(officialList);
        super.onPostExecute(officialList);
    }

}
