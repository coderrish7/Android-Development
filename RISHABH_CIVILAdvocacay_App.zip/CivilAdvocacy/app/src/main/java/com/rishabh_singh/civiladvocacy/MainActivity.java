package com.rishabh_singh.civiladvocacy;

import static android.content.pm.PackageManager.PERMISSION_GRANTED;

import androidx.activity.result.ActivityResult;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import Model.Official;
import adapter.OfficialAdapter;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "MainActivity";
    private final ArrayList<Official> officialList = new ArrayList<>();
    private RecyclerView view;
    @SuppressLint("StaticFieldLeak")
    static MainActivity mainActivity;

    private TextView location_info,location_warning;

    OfficialAdapter adapter;

    private String presentLocation;


    private static final int LOCATION_REQUEST = 111;
    private SwipeRefreshLayout swiperLayout;

    private FusedLocationProviderClient providerClient;
    private String locationString = "Unspecified Location";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);

        swiperLayout = findViewById(R.id.swiperlayout);
        mainActivity = this;
        view = findViewById(R.id.recycler_view);
        location_info = findViewById(R.id.location_title);
        location_warning = findViewById(R.id.Warning_Alert);
        presentLocation = "";
        swiperLayout.setOnRefreshListener(this::onRefresh);
        providerClient =
                LocationServices.getFusedLocationProviderClient(mainActivity);
        presentLocation = determineLocationInfo();

        adapter = new OfficialAdapter(officialList, this);
        view.setAdapter(adapter);
        view.setLayoutManager(new LinearLayoutManager(this));

        if (!presentLocation.equals("")) {
            if (checkNetwork()) {
                new GovtDataExtractor(MainActivity.this).execute(presentLocation);
            } else {
                setupNetworkDialog(getString(R.string.networkError1));
                warningShow("Please mention a location!");
            }
            if (location_info.getText().toString().equals("No Data For Location")) warningShow("close app and reopen!");
        }
    }

    private boolean checkAppPermissions() {
        boolean hasFineLocationPermission = ContextCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;

        if (!hasFineLocationPermission) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_REQUEST);
            return false;
        }

        return true;
    }

    @SuppressLint("SetTextI18n")
    private String getplaceInfo(Location loc) {

        StringBuilder sb = new StringBuilder();

        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        List<Address> addresses;
        String addressLine = "";

        try {
            addresses = geocoder.getFromLocation(loc.getLatitude(), loc.getLongitude(), 1);
            if(addresses.size() > 0)
                addressLine = addresses.get(0).getAddressLine(0);
            else {
                addresses.size();
                ((TextView) findViewById(R.id.location_title)).setText("No Data For Location");

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return addressLine;
    }
    public void downloadFailed() {
        Toast.makeText(this, "Please specify the correct location", Toast.LENGTH_SHORT).show();
    }

    @SuppressLint("MissingPermission")
    private String determineLocationInfo() {
        if (checkAppPermissions()) {
            providerClient.getLastLocation()
                    .addOnSuccessListener(this, location -> {
                        if (location != null) {
                            locationString = getplaceInfo(location);
                            presentLocation = locationString;

                            new GovtDataExtractor(MainActivity.this).execute(presentLocation);
                        }
                    })
                    .addOnFailureListener(this, e -> Toast.makeText(MainActivity.this,
                            e.getMessage(), Toast.LENGTH_LONG).show());
            return locationString;
        }
        return locationString;
    }

    public boolean isLocationEnabled() {
        int locationMode = Settings.Secure.getInt(
                getContentResolver(),
                Settings.Secure.LOCATION_MODE,
                Settings.Secure.LOCATION_MODE_OFF
        );
        return (locationMode != Settings.Secure.LOCATION_MODE_OFF);
    }



    public void openAboutActivity(MenuItem item) {
        Intent intent = new Intent(this, AboutActivity.class);
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Log.e(TAG, "Error opening AboutActivity: " + e.getMessage());
        }
    }


    public void setupNetworkDialog(String message) {
        AlertDialog dialog;
        dialog = new AlertDialog.Builder(this)
                .setIcon(R.drawable.ic_baseline_error)
                .setTitle(R.string.networkError0)
                .setMessage(message)
                .create();
        dialog.show();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_item_list, menu);
        return true;
    }

    public void setSearchDialog() {
        final EditText editText = new EditText(this);
        editText.setGravity(Gravity.CENTER_HORIZONTAL);

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setIcon(R.drawable.ic_search_accent)
                .setTitle(R.string.searchTitle)
                .setMessage(R.string.searchMessage)
                .setView(editText)
                .setPositiveButton("Search", (dialog, id) -> {
                    String searchString = editText.getText().toString().trim();
                    if (!searchString.equals("")) {
                        location_info.setText(searchString);
                        new GovtDataExtractor(MainActivity.this).execute(searchString);
                    } else {
                        Toast.makeText(MainActivity.this, R.string.nullStringMsg, Toast.LENGTH_SHORT).show();
                        setSearchDialog();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.location_section_menu) {
            handleLocationMenuOption();
        } else if (itemId == R.id.about_section_menu) {
            handleAboutMenuOption(item);
        } else {
            handleInvalidMenuOption();
        }

        return super.onOptionsItemSelected(item);
    }
    public void onBackPressed() {
        Toast.makeText(this, getResources().getString(R.string.bck_btn_bye_msg), Toast.LENGTH_LONG).show();
        super.onBackPressed();
    }
    private void handleLocationMenuOption() {
        if (checkNetwork()) {
            setSearchDialog();
        } else {
            setupNetworkDialog(getString(R.string.networkError2));
        }
    }

    private void handleAboutMenuOption(MenuItem item) {
        startActivity(new Intent(this, AboutActivity.class));
    }


    private void handleInvalidMenuOption() {
        Toast.makeText(this, "Invalid Option", Toast.LENGTH_SHORT).show();
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_REQUEST) {
            if (permissions[0].equals(Manifest.permission.ACCESS_FINE_LOCATION) && grantResults[0] == PERMISSION_GRANTED) {
                providerClient =
                        LocationServices.getFusedLocationProviderClient(mainActivity);
                presentLocation = determineLocationInfo();
                if (!presentLocation.equals("")) {
                    if (!checkNetwork()) {
                        setupNetworkDialog(getString(R.string.networkError1));
                    } else {
                        new GovtDataExtractor(MainActivity.this).execute(presentLocation);
                    }
                }
                else
                    setupLocationDialog("Location unavailable", 1);

                return;
            }
        }
        setupLocationDialog(getString(R.string.locationError1), 0);
        location_info.setText(R.string.no_permission);
    }

    @SuppressLint("NotifyDataSetChanged")
    public void updateOfficialData(ArrayList<Official> updatedOfficialList) {
        officialList.clear();
        if (updatedOfficialList.isEmpty()) {
            if (isLocationEnabled()) {
            } else {
                location_info.setText(getText(R.string.no_location_warning));
                location_warning.setVisibility(View.VISIBLE);
            }
        } else {
            officialList.addAll(updatedOfficialList);
            location_warning.setVisibility(View.GONE);
        }
        adapter.notifyDataSetChanged();
        warningClose();
    }

    private void handleResult(ActivityResult result) {
        //Toast.makeText(this, "Coming from OfficialActivity Class", Toast.LENGTH_SHORT).show();
    }

    protected void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putString("KEY_locationstring", location_info.getText().toString());

        super.onSaveInstanceState(savedInstanceState);
    }
    public void setupLocationDialog(String message, int dismissFlag) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setIcon(R.drawable.ic_baseline_error)
                .setTitle(R.string.locationError0)
                .setMessage(message);
        AlertDialog alertDialog = builder.create();

        if (dismissFlag == 0) {
            alertDialog.show();
        } else if (dismissFlag == 1) {
            alertDialog.dismiss();
        }
    }
    public void clearOfficial(){
        officialList.clear();
    }

    public Boolean checkNetwork()
    {
        ConnectivityManager connectivityManager;
        connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo;
        networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null) return networkInfo.isConnectedOrConnecting();
        return false;
    }

    @Override
    protected void onPause() {
        super.onPause();
    }


    @Override
    public void onClick(View view) {
        int position;
        position = this.view.getChildAdapterPosition(view);
        Official temp;
        temp = officialList.get(position);
        Intent i;
        i = new Intent(this, OfficialDetailActivity.class);
        i.putExtra("location", location_info.getText());
        i.putExtra("official", temp);
         startActivity(i);
    }
    public boolean onLongClick(View view) {
        //Toast.makeText(this,"Long Click", Toast.LENGTH_SHORT).show();
        return true;
    }

    @SuppressLint({"SetTextI18n", "NotifyDataSetChanged"})
    public void errorLocation() {
        officialList.clear();
        TextView locationText = findViewById(R.id.location_title);
        locationText.setText("Location Unavailable: " + presentLocation);
        boolean showWarning = true;
        warningShow("Please try again with a valid location in the United States.");
        adapter.notifyDataSetChanged();
    }

    public void warningShow(String update) {
        TextView location_warning = findViewById(R.id.Warning_Alert);
        location_warning.setVisibility(View.VISIBLE);
        location_warning.setText(update);
    }
    public void warningClose(){
        location_warning.setVisibility(View.INVISIBLE);
    }

    private void onRefresh() {
        providerClient =
                LocationServices.getFusedLocationProviderClient(mainActivity);
        presentLocation = determineLocationInfo();

        if (!presentLocation.equals("Unspecified Location")) if (checkNetwork()) {
            new GovtDataExtractor(MainActivity.this).execute(presentLocation);
        } else {
            warningShow("No location, please restart the app and grant location access");
            setupNetworkDialog(getString(R.string.networkError1));
        }

        else if (!isLocationEnabled())
            setupLocationDialog(getString(R.string.locationError1), 0);

        swiperLayout.setRefreshing(false);
    }
}