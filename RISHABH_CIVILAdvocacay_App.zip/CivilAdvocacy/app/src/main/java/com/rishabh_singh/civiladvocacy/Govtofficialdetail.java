package com.rishabh_singh.civiladvocacy;

import java.io.Serializable;

public class Govtofficialdetail implements Serializable {



    public Govtofficialdetail(String type, String id) {
        if (type == null || type.isEmpty()) {
            throw new IllegalArgumentException("Type cannot be empty");
        }
        if (id == null || id.isEmpty()) throw new IllegalArgumentException("ID cannot be empty");
        this.type = type;
        this.id = id;
    }


    public String getType()
    {
        return type;
    }
    private String type;
    private String id;
    public String getId()
    {
        return id;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setId(String id) {
        this.id = id;
    }

}

