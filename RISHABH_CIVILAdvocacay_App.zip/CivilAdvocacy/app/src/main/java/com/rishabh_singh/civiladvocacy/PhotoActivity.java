package com.rishabh_singh.civiladvocacy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import Model.Official;

public class PhotoActivity extends AppCompatActivity {

    private ImageView photoOfficial;
    private ImageView partyLogoOfficial;
    private TextView locationDisplay;
    private TextView titleOfficial;
    private TextView nameOfficial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo);

        initializeViews();

        Intent intent = getIntent();
        Official official = (Official) intent.getSerializableExtra("official");
        CharSequence location = intent.getCharSequenceExtra("location");

        locationDisplay.setText(location);
        titleOfficial.setText(official.getTitle());
        nameOfficial.setText(official.getName());

        Picasso picasso = Picasso.get();
        String photoURL = official.getPhotoURL();
        if (photoURL != null) {
            picasso.load(photoURL.replace("http:", "https:"))
                    .error(R.drawable.brokenimage)
                    .placeholder(R.drawable.missing)
                    .into(photoOfficial);
        } else {
            picasso.load(photoURL)
                    .error(R.drawable.brokenimage)
                    .placeholder(R.drawable.missing)
                    .into(photoOfficial);
        }

        setPartyLogoAndBackground(official.getParty());
    }

    private void initializeViews() {
        photoOfficial = findViewById(R.id.photoOfficial);
        partyLogoOfficial = findViewById(R.id.partyLogoOfficial);
        locationDisplay = findViewById(R.id.location_display);
        titleOfficial = findViewById(R.id.TitleOfficial);
        nameOfficial = findViewById(R.id.NameOfficial);
    }

    private void setPartyLogoAndBackground(String party) {
        if (party == null) {
            return;
        }

        int backgroundColor = Color.BLACK;
        int partyLogoResource = 0;

        if (party.contains("Republican")) {
            backgroundColor = Color.RED;
            partyLogoResource = R.drawable.rep_logo;
        } else if (party.contains("Democratic")) {
            backgroundColor = Color.BLUE;
            partyLogoResource = R.drawable.dem_logo;
        } else if (party.contains("Nonpartisan")) {
            backgroundColor = Color.BLACK;
            partyLogoResource = R.drawable.non_logo;
        } else {
            partyLogoOfficial.setVisibility(View.INVISIBLE);
        }

        getWindow().getDecorView().setBackgroundColor(backgroundColor);
        partyLogoOfficial.setImageResource(partyLogoResource);
    }
}
