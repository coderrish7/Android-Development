package com.rishabh_singh.civiladvocacy;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.util.Linkify;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import Model.Official;

public class OfficialDetailActivity extends AppCompatActivity {

    private static final String TAG = OfficialDetailActivity.class.getName();

    private TextView official_title;
    private TextView official_name;
    private TextView official_party;
    private TextView address_detail;
    private TextView addrresslabel;
    private TextView email_detail;
    private TextView emaillabel;
    private TextView urlTextView;
    private TextView urllabel;
    private TextView phone_detail;
    private TextView phonelabel;
    private TextView locationToolBar;

    private ImageView partyprofile_Image;

    private ImageView partyLogo,fbLogo,twLogo,ytLogo;

    private ConstraintLayout layout;
    private ConstraintLayout layout1;

    private Govtofficialdetail fbHandle;
    private Govtofficialdetail twHandle;
    private Govtofficialdetail ytHandle;

    private Official usa_officer_info;


    private void addLinksToTextView(TextView textView) {
        Linkify.addLinks(textView, Linkify.ALL);
    }

    @SuppressLint({"ResourceAsColor", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_official_detail);
        layoutdesign();
        updateLocation();
        Intent intent = getIntent();
        locationToolBar.setText(intent.getCharSequenceExtra(getString(R.string.LOC)));
        usa_officer_info = (Official) intent.getSerializableExtra(getString(R.string.OFFI));
        address_detail.setText(usa_officer_info.getAddress());
        if (null != usa_officer_info.getTitle())
            official_title.setText(usa_officer_info.getTitle());
        official_name.setText(usa_officer_info.getName());

        Picasso picasso = Picasso.get();

        if (usa_officer_info.getParty() != null) {

            if (usa_officer_info.getParty().contains("Republican")){
                getWindow().getDecorView().setBackgroundColor(Color.RED);
                official_party.setText(usa_officer_info.getParty());
                official_party.setTextColor(Color.WHITE);
                partyLogo.setImageResource(R.drawable.rep_logo);
            }
            else if (usa_officer_info.getParty().contains("Democratic")) {
                official_party.setText(usa_officer_info.getParty());
                getWindow().getDecorView().setBackgroundColor(Color.BLUE);
                partyLogo.setImageResource(R.drawable.dem_logo);
            }
            else {
                if (usa_officer_info.getParty().contains("Nonpartisan")) {
                    getWindow().getDecorView().setBackgroundColor(Color.BLACK);
                    partyLogo.setImageResource(R.drawable.non_logo);
                    official_party.setText(usa_officer_info.getParty());

                }
            }
        } else {
            getWindow().getDecorView().setBackgroundColor(Color.BLACK);
        }

        if (usa_officer_info.getAddress() != null&& !usa_officer_info.getAddress().isEmpty()) {
            address_detail.setText(usa_officer_info.getAddress().trim());
            Linkify.addLinks(address_detail,
                    Linkify.ALL);
            address_detail.setLinkTextColor(getColor(R.color.white));
        } else {
            addrresslabel.setVisibility(View.GONE);
            address_detail.setVisibility(View.GONE);
            ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, 0, 0, 0);
            phonelabel.setLayoutParams(params);
        }


        if (usa_officer_info.getPhones() != null && !usa_officer_info.getPhones().isEmpty())
            phone_detail.setText(usa_officer_info.getPhones());
        else
        {
            phonelabel.setVisibility(View.GONE);
            phone_detail.setVisibility(View.GONE);
        }

        if (usa_officer_info.getEmails() != null && !usa_officer_info.getEmails().isEmpty()) {
            email_detail.setText(usa_officer_info.getEmails());
        }
        else {

            email_detail.setVisibility(View.GONE);
            emaillabel.setVisibility(View.GONE);
        }

        if (usa_officer_info.getUrls() != null && !usa_officer_info.getUrls().isEmpty())
            urlTextView.setText(usa_officer_info.getUrls());
        else {
            urllabel.setVisibility(View.GONE);
            urlTextView.setText("No URL provided");
        }


        if (usa_officer_info.getPhotoURL() != null){
            try {
                picasso.load(usa_officer_info.getPhotoURL().replace("http:", "https:")).error(R.drawable.brokenimage)
                        .placeholder(R.drawable.missing).into(partyprofile_Image);
            }
            catch (Exception e)
            {
                picasso.load(R.drawable.missing) .into(partyprofile_Image);
            }
        }
        else
        {
            picasso.load(usa_officer_info.getPhotoURL()) .error(R.drawable.brokenimage)
                    .placeholder(R.drawable.missing) .into(partyprofile_Image);
        }

        if (usa_officer_info.getGovtofficialdetailArrayList() != null) {
            ArrayList<Govtofficialdetail> channelModels = usa_officer_info.getGovtofficialdetailArrayList();
            if (channelModels.size() > 0) {
                for (Govtofficialdetail single_channelModel : channelModels) {
                    switch(single_channelModel.getType()) {
                        case "Facebook":
                            fbHandle = single_channelModel;
                            fbLogo.setVisibility(View.VISIBLE);
                            break;
                        case "Twitter":
                            twHandle = single_channelModel;
                            twLogo.setVisibility(View.VISIBLE);
                            break;
                        case "YouTube":
                            ytHandle = single_channelModel;
                            ytLogo.setVisibility(View.VISIBLE);
                            break;
                        default:
                            break;
                    }
                }
            }
        } else {
            ytLogo.setVisibility(View.INVISIBLE);
            twLogo.setVisibility(View.INVISIBLE);
            fbLogo.setVisibility(View.INVISIBLE);
        }

        addLinksToTextView(address_detail);
        addLinksToTextView(email_detail);
        addLinksToTextView(phone_detail);
        addLinksToTextView(urlTextView);

    }


    @Override
    protected void onPause() {
        super.onPause();
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    void layoutdesign() {

        phonelabel = findViewById(R.id.phone_info);
        locationToolBar = findViewById(R.id.locationToolBar);
        official_party = findViewById(R.id.official_party);
        addrresslabel = findViewById(R.id.addrress_info);
        phone_detail = findViewById(R.id.phone_display);
        address_detail = findViewById(R.id.address_display);
        emaillabel = findViewById(R.id.email_info);
        email_detail = findViewById(R.id.email_display);
        ConstraintLayout layout = findViewById(R.id.constraintLayout);
        ConstraintLayout layout1 = findViewById(R.id.detailsSection);
        urllabel = findViewById(R.id.website_display);
        official_title = findViewById(R.id.official_Title);
        official_name = findViewById(R.id.official_name);
        urlTextView = findViewById(R.id.website_info);
        partyprofile_Image = findViewById(R.id.profile_picture);
        partyLogo = findViewById(R.id.partyImage);
        fbLogo = findViewById(R.id.facebookImage);
        twLogo = findViewById(R.id.twitterImage);
        ytLogo = findViewById(R.id.youtubeImage);

    }

    void updateLocation() {
        String locationText = getIntent().hasExtra("locationToolBar") ? getIntent().getStringExtra("locationToolBar") : "";
        locationToolBar.setText(locationText);
    }


    public void onProfileImageClick(View v) {
        if (TextUtils.isEmpty(usa_officer_info.getPhotoURL())) {
            Toast.makeText(this, "No Profile Picture Available", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent i = new Intent(this, PhotoActivity.class);
        i.putExtra("location", locationToolBar.getText());
        i.putExtra("official", usa_officer_info);
        startActivity(i);
    }


    public void onPartyLogoClicked(View v) {
        String partyUrl = null;
        if (!usa_officer_info.getParty().toLowerCase().contains("democratic")) {
            if (usa_officer_info.getParty().toLowerCase().contains("republican")) {
                partyUrl = "https://www.gop.com";
            }
        } else {
            partyUrl = "https://democrats.org";
        }
        if (partyUrl != null) {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(partyUrl));
            startActivity(i);
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        }
    }
    /*  public boolean isPackageInstalled(String packageName) {
         try {
             return getPackageManager().getApplicationInfo(packageName, 0).enabled;
         }
         catch (PackageManager.NameNotFoundException e) {
             return false;
         }

     */
    public void onFacebookImageClicked(View v) {
        String id = fbHandle.getId();
        String facebookUrl = "https://www.facebook.com/" + id;
        String url;
        PackageManager packageManager = getPackageManager();
        try {
            int versionCode = packageManager.getPackageInfo("com.facebook.katana", 0).versionCode;
            if (versionCode >= 3002850) { //newer versions of fb app
                url = "fb://facewebmodal/f?href=" + facebookUrl;
            } else { //older versions of fb app
                url = "fb://page/" + id;
            }
        } catch (PackageManager.NameNotFoundException e) {
            url = facebookUrl; //normal web website_info
        }
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }


    public void onTwitterClicked(View v) {
        Intent intent;
        String id = twHandle.getId();
        try {
            getPackageManager().getPackageInfo("com.twitter.android", 0);
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("twitter://user?screen_name=" + id));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        } catch (Exception e) {
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/" + id));
        }
        startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    public void youTubeClicked(View v) {
        String id = ytHandle.getId();
        Intent intent;
        try {
            intent = new Intent(Intent.ACTION_VIEW);
            intent.setPackage("com.google.android.youtube");
            intent.setData(Uri.parse("https://www.youtube.com/" + id));
            startActivity(intent);
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/" + id)));
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        }
    }

}