package adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.rishabh_singh.civiladvocacy.MainActivity;
import Model.Official;
import com.rishabh_singh.civiladvocacy.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class OfficialAdapter  extends RecyclerView.Adapter<OfficialAdapter.OfficialViewHolder>{

    private final List<Official> officialList;
    private final MainActivity activity;

    public OfficialAdapter(ArrayList<Official> officialList, MainActivity activity) {
        this.activity = activity;
        this.officialList = officialList;
    }

    @NonNull
    @Override
    public OfficialViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_entry,parent,false);
        itemView.setOnClickListener(activity);
        return new OfficialViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull OfficialViewHolder holder, int position) {
        Official tempOfficial = officialList.get(position);
        Picasso picasso = Picasso.get();
        try {
            picasso.load(tempOfficial.getPhotoURL().replace("http:", "https:")) .error(R.drawable.missing)
                    .placeholder(R.drawable.missing).into(holder.imageViewOfficial);

        } catch (IllegalArgumentException ae) {
            Picasso.get().load(R.drawable.missing).into(holder.imageViewOfficial);
        }
        holder.officialTitle.setText(tempOfficial.getTitle());
        holder.officialName.setText(tempOfficial.getName());
        holder.officialParty.setText(tempOfficial.getParty());
    }

    @Override
    public int getItemCount() {
        return officialList.size();
    }

    static class OfficialViewHolder extends RecyclerView.ViewHolder {
        private final ImageView imageViewOfficial;
        private final TextView officialTitle;
        private final TextView officialName;
        private final TextView officialParty;

        public OfficialViewHolder(@NonNull View itemView) {
            super(itemView);
            imageViewOfficial = itemView.findViewById(R.id.Official_image_info);
            officialTitle = itemView.findViewById(R.id.official_title_info);
            officialName = itemView.findViewById(R.id.Official_name_info);
            officialParty = itemView.findViewById(R.id.Official_party_info);
        }
    }

}
